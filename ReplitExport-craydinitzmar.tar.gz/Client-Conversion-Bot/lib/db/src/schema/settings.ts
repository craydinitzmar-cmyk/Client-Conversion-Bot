import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  starterPrice: text("starter_price").notNull().default("£20/month"),
  businessPrice: text("business_price").notNull().default("£50/month"),
  premiumPrice: text("premium_price").notNull().default("£99/month"),
  starterDescription: text("starter_description").notNull().default("Perfect for solo businesses getting started with AI support."),
  businessDescription: text("business_description").notNull().default("Ideal for growing businesses with higher chat volume."),
  premiumDescription: text("premium_description").notNull().default("Full-scale AI support for busy businesses that need maximum coverage."),
  paypalUrl: text("paypal_url").notNull().default("https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7"),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
