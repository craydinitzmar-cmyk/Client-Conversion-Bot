import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";

export const emailQueueTable = pgTable("email_queue", {
  id: serial("id").primaryKey(),
  leadId: integer("lead_id"),
  toEmail: text("to_email").notNull(),
  toName: text("to_name").notNull(),
  subject: text("subject").notNull(),
  bodyHtml: text("body_html").notNull(),
  sequenceStep: integer("sequence_step").notNull(),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  status: text("status").notNull().default("pending"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type EmailQueueItem = typeof emailQueueTable.$inferSelect;
