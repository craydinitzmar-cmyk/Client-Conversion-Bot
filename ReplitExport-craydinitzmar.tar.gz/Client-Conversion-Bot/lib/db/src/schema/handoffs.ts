import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const handoffsTable = pgTable("handoffs", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull().unique(),
  flagReason: text("flag_reason").notNull(),
  triggerMessage: text("trigger_message").notNull(),
  status: text("status").notNull().default("pending"),
  flaggedAt: timestamp("flagged_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  resolvedNote: text("resolved_note"),
});

export type Handoff = typeof handoffsTable.$inferSelect;
