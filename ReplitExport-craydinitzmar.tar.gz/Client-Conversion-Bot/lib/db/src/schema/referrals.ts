import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const referralsTable = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerEmail: text("referrer_email").notNull(),
  referralCode: text("referral_code").notNull().unique(),
  referredEmail: text("referred_email"),
  referredName: text("referred_name"),
  status: text("status").notNull().default("pending"),
  reward: text("reward").notNull().default("1 month free"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  convertedAt: timestamp("converted_at", { withTimezone: true }),
});

export type Referral = typeof referralsTable.$inferSelect;
