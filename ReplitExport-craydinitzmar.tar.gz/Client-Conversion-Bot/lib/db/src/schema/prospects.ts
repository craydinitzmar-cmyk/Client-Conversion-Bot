import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const prospectsTable = pgTable("prospects", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  industry: text("industry").notNull(),
  contactName: text("contact_name"),
  email: text("email"),
  website: text("website"),
  notes: text("notes"),
  status: text("status").notNull().default("new"),
  outreachSentAt: timestamp("outreach_sent_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Prospect = typeof prospectsTable.$inferSelect;
