import { useEffect } from "react";

const REF_KEY = "botly_ref";

export function useTrackReferral() {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) {
      sessionStorage.setItem(REF_KEY, ref.toUpperCase());
    }
  }, []);
}

export function getStoredRefCode(): string | null {
  return sessionStorage.getItem(REF_KEY);
}

export async function convertReferral(referredEmail: string, referredName: string): Promise<void> {
  const refCode = getStoredRefCode();
  if (!refCode) return;
  try {
    await fetch(`${import.meta.env.BASE_URL}api/referrals/convert`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refCode, referredEmail, referredName }),
    });
    sessionStorage.removeItem(REF_KEY);
  } catch {
    // silent — referral tracking must never break lead capture
  }
}

export async function getReferralCode(email: string): Promise<string | null> {
  try {
    const res = await fetch(
      `${import.meta.env.BASE_URL}api/referrals/code?email=${encodeURIComponent(email)}`
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data.code ?? null;
  } catch {
    return null;
  }
}

export async function getReferralStats(email: string) {
  const res = await fetch(
    `${import.meta.env.BASE_URL}api/referrals/stats?email=${encodeURIComponent(email)}`
  );
  if (!res.ok) throw new Error("Failed to load stats");
  return res.json();
}
