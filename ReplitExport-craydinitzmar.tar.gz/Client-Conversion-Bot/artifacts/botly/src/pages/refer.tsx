import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Copy, Gift, Users, Star, ArrowRight, Share2 } from "lucide-react";
import { getReferralCode, getReferralStats } from "@/hooks/use-referral";

const BASE = window.location.origin;

interface Stats {
  total: number;
  converted: number;
  pending: number;
  monthsFree: number;
  referrals: Array<{
    id: number;
    referredName: string | null;
    referredEmail: string | null;
    status: string;
    convertedAt: string | null;
  }>;
}

export default function ReferPage() {
  const [email, setEmail] = useState("");
  const [refCode, setRefCode] = useState<string | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");

  const referralLink = refCode ? `${BASE}/?ref=${refCode}` : "";

  const handleGetLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    setError("");
    try {
      const code = await getReferralCode(email);
      if (!code) { setError("Something went wrong. Try again."); return; }
      setRefCode(code);
      const s = await getReferralStats(email);
      setStats(s);
    } catch {
      setError("Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `I've been using Botly to capture leads and automate my customer support — it's brilliant. You can try it here: ${referralLink}`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  const handleEmail = () => {
    const subject = encodeURIComponent("You need to try this AI for your business");
    const body = encodeURIComponent(
      `Hey,\n\nI've been using Botly to handle customer enquiries and capture leads automatically. It's been great for my business.\n\nYou can try it here: ${referralLink}\n\nThought you might find it useful!`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`);
  };

  return (
    <div className="flex flex-col items-center">

      {/* Hero */}
      <section className="w-full py-20 px-4 bg-zinc-950 text-white text-center">
        <div className="container max-w-2xl mx-auto">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
            <Gift className="h-8 w-8 text-yellow-400" />
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Refer a business. <br />
            <span className="text-indigo-400">Earn free months.</span>
          </h1>
          <p className="text-zinc-400 text-lg mb-8 leading-relaxed">
            For every business owner you refer who signs up to Botly, you earn <strong className="text-white">1 month completely free</strong>. No limits. Refer 12, get a whole year free.
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-sm text-zinc-500">
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> No limit on referrals</span>
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> 1 free month per sign-up</span>
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> Instant reward tracking</span>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="w-full py-16 px-4 bg-white border-b border-zinc-100">
        <div className="container max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-10">How it works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { step: "1", icon: Share2, title: "Get your link", body: "Enter your email below to generate your unique referral link." },
              { step: "2", icon: Users, title: "Share with businesses", body: "Send it to salon owners, coaches, restaurants — anyone who talks to customers." },
              { step: "3", icon: Gift, title: "Earn free months", body: "Every time someone signs up through your link, you get 1 month free. Automatically." },
            ].map(({ step, icon: Icon, title, body }) => (
              <div key={step} className="flex flex-col items-center text-center p-6 rounded-2xl bg-zinc-50 border border-zinc-100">
                <div className="h-12 w-12 rounded-full bg-zinc-900 text-white flex items-center justify-center mb-4">
                  <Icon className="h-5 w-5" />
                </div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">Step {step}</p>
                <h3 className="font-bold mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Get your link */}
      <section className="w-full py-20 px-4 bg-zinc-50">
        <div className="container max-w-lg mx-auto">
          <h2 className="text-3xl font-bold text-center mb-2">Get your referral link</h2>
          <p className="text-center text-muted-foreground mb-8">Enter the email you use (or plan to use) with Botly.</p>

          {!refCode ? (
            <form onSubmit={handleGetLink} className="space-y-3">
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-14 rounded-xl text-base"
                required
              />
              {error && <p className="text-sm text-red-500">{error}</p>}
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-14 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl text-base"
              >
                {loading ? "Generating..." : "Get My Referral Link"}
                {!loading && <ArrowRight className="ml-2 h-5 w-5" />}
              </Button>
            </form>
          ) : (
            <div className="space-y-4">
              {/* Link display */}
              <Card className="rounded-2xl border-zinc-200">
                <CardContent className="pt-5 pb-4">
                  <p className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wide">Your referral link</p>
                  <div className="flex items-center gap-2 bg-zinc-950 rounded-xl px-4 py-3">
                    <span className="text-sm text-zinc-300 font-mono flex-1 truncate">{referralLink}</span>
                    <Button size="sm" variant="ghost" onClick={handleCopy} className="text-zinc-400 hover:text-white shrink-0 gap-1.5">
                      {copied ? <><Check className="h-3.5 w-3.5 text-green-400" /> Copied</> : <><Copy className="h-3.5 w-3.5" /> Copy</>}
                    </Button>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button onClick={handleWhatsApp} variant="outline" className="flex-1 gap-2 text-sm rounded-xl">
                      Share on WhatsApp
                    </Button>
                    <Button onClick={handleEmail} variant="outline" className="flex-1 gap-2 text-sm rounded-xl">
                      Share by Email
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Stats */}
              {stats && (
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Total referrals", value: stats.total },
                    { label: "Converted", value: stats.converted },
                    { label: "Months earned", value: stats.monthsFree },
                  ].map(({ label, value }) => (
                    <Card key={label} className="rounded-xl border-zinc-200 text-center">
                      <CardContent className="pt-4 pb-3">
                        <div className="text-3xl font-extrabold text-zinc-900">{value}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Referral history */}
              {stats && stats.referrals.length > 0 && (
                <Card className="rounded-2xl border-zinc-200">
                  <CardContent className="pt-5">
                    <p className="text-sm font-semibold mb-3">Referral history</p>
                    <div className="space-y-2">
                      {stats.referrals.map((r) => (
                        <div key={r.id} className="flex items-center justify-between py-2 border-b border-zinc-100 last:border-0">
                          <div>
                            <p className="text-sm font-medium text-zinc-900">{r.referredName ?? "Pending sign-up"}</p>
                            {r.referredEmail && <p className="text-xs text-muted-foreground">{r.referredEmail}</p>}
                          </div>
                          <Badge variant="outline" className={r.status === "converted" ? "border-green-300 text-green-700 bg-green-50" : "border-zinc-300 text-zinc-500"}>
                            {r.status === "converted" ? "Converted" : "Pending"}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {stats && stats.referrals.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  No referrals yet. Share your link and start earning free months.
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Testimonial */}
      <section className="w-full py-16 px-4 bg-white border-t border-zinc-100">
        <div className="container max-w-xl mx-auto text-center">
          <div className="flex gap-0.5 justify-center mb-4">
            {Array(5).fill(0).map((_, i) => <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="text-lg font-medium text-zinc-900 leading-relaxed mb-4">
            "I referred 4 salon owners in my network and haven't paid for Botly in 4 months. It basically runs for free now."
          </p>
          <p className="text-sm text-muted-foreground">Jamie O. — Restaurant owner, Birmingham</p>
        </div>
      </section>
    </div>
  );
}
