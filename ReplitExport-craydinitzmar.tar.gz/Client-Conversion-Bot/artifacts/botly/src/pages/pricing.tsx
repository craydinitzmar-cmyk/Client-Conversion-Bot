import { useState } from "react";
import { useGetSettings } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Check, Shield, Zap, Star, ChevronDown, ChevronUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

const PAYPAL_URL = "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

const plans = [
  {
    key: "starter",
    name: "Starter",
    monthly: 20,
    annual: 16,
    description: "Perfect for solo businesses and freelancers just getting started.",
    features: [
      "Up to 100 chats/month",
      "Basic lead capture",
      "FAQ knowledge base",
      "Chat logs dashboard",
      "Email notifications",
      "Standard support",
    ],
    cta: "Get Starter",
    popular: false,
  },
  {
    key: "business",
    name: "Business",
    monthly: 50,
    annual: 40,
    description: "Ideal for growing businesses with higher chat volume and a team.",
    features: [
      "Up to 1,000 chats/month",
      "Advanced intent detection",
      "Priority lead capture",
      "Chat logs + transcripts",
      "Email + dashboard alerts",
      "Priority support",
      "Custom AI training",
    ],
    cta: "Get Business",
    popular: true,
  },
  {
    key: "premium",
    name: "Premium",
    monthly: 99,
    annual: 79,
    description: "Full-scale AI support for busy businesses needing maximum coverage.",
    features: [
      "Unlimited chats",
      "Everything in Business",
      "White-glove AI setup",
      "Dedicated account manager",
      "24/7 priority support",
      "Custom branding on widget",
      "Monthly performance review",
    ],
    cta: "Get Premium",
    popular: false,
  },
];

const faqs = [
  { q: "Can I switch plans later?", a: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect on your next billing cycle." },
  { q: "How does annual billing work?", a: "You're billed once per year at the discounted rate. That's equivalent to getting over 2 months free compared to monthly billing." },
  { q: "What payment methods do you accept?", a: "We accept all major cards and PayPal via our secure PayPal payment page." },
  { q: "Is there a free trial?", a: "Yes — we offer a 7-day free setup period so you can see the AI in action before you're fully committed." },
];

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-zinc-200 last:border-0">
      <button className="w-full flex items-center justify-between py-5 text-left font-semibold text-zinc-900 hover:text-zinc-700 transition-colors" onClick={() => setOpen(!open)}>
        {q}
        {open ? <ChevronUp className="h-4 w-4 shrink-0 text-zinc-500" /> : <ChevronDown className="h-4 w-4 shrink-0 text-zinc-500" />}
      </button>
      {open && <p className="pb-5 text-muted-foreground text-sm leading-relaxed">{a}</p>}
    </div>
  );
}

export default function Pricing() {
  const [annual, setAnnual] = useState(false);
  const { isLoading } = useGetSettings({ query: { queryKey: ["settings"] } });

  return (
    <div className="flex flex-col items-center bg-white">

      {/* Header */}
      <section className="w-full pt-20 pb-12 px-4 text-center">
        <div className="container max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 px-3 py-1 text-sm font-medium mb-6">
            <Zap className="h-3.5 w-3.5" /> Launch pricing — save up to 20% annually
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">Simple, transparent pricing</h1>
          <p className="text-xl text-muted-foreground max-w-xl mx-auto mb-10">
            One flat fee. No hidden charges. Cancel anytime.
          </p>

          {/* Billing toggle */}
          <div className="inline-flex items-center bg-zinc-100 rounded-full p-1 gap-1">
            <button
              onClick={() => setAnnual(false)}
              className={`px-5 py-2 rounded-full text-sm font-semibold transition-all ${!annual ? "bg-white shadow text-zinc-900" : "text-zinc-500 hover:text-zinc-700"}`}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={`px-5 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 ${annual ? "bg-white shadow text-zinc-900" : "text-zinc-500 hover:text-zinc-700"}`}
            >
              Annual
              <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded-full">Save 20%</span>
            </button>
          </div>
        </div>
      </section>

      {/* Plans */}
      <section className="w-full pb-20 px-4">
        <div className="container max-w-5xl mx-auto">
          {isLoading ? (
            <div className="grid md:grid-cols-3 gap-6">
              {[1,2,3].map(i => <Skeleton key={i} className="h-96 rounded-2xl" />)}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6 items-start">
              {plans.map((plan) => (
                <div
                  key={plan.key}
                  className={`rounded-3xl p-8 flex flex-col relative transition-transform ${
                    plan.popular
                      ? "bg-zinc-950 text-white shadow-2xl md:-translate-y-4 border border-zinc-800"
                      : "bg-white border border-zinc-200 shadow-sm"
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-1.5 rounded-full text-xs font-bold tracking-wide uppercase">
                      Most Popular
                    </div>
                  )}

                  <h3 className={`text-xl font-bold mb-2 ${plan.popular ? "text-white" : "text-zinc-900"}`}>{plan.name}</h3>

                  <div className="flex items-end gap-1 mb-1">
                    <span className="text-4xl font-extrabold tracking-tight">
                      £{annual ? plan.annual : plan.monthly}
                    </span>
                    <span className={`text-sm mb-1.5 ${plan.popular ? "text-zinc-400" : "text-muted-foreground"}`}>/month</span>
                  </div>
                  {annual && (
                    <p className={`text-xs mb-3 ${plan.popular ? "text-zinc-500" : "text-muted-foreground"}`}>
                      billed £{plan.annual * 12}/year · save £{(plan.monthly - plan.annual) * 12}
                    </p>
                  )}

                  <p className={`text-sm mb-7 leading-relaxed ${plan.popular ? "text-zinc-400" : "text-muted-foreground"}`}>
                    {plan.description}
                  </p>

                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm">
                        <div className={`rounded-full p-0.5 mt-0.5 shrink-0 ${plan.popular ? "bg-indigo-600" : "bg-zinc-100"}`}>
                          <Check className={`h-3.5 w-3.5 ${plan.popular ? "text-white" : "text-zinc-700"}`} />
                        </div>
                        <span className={plan.popular ? "text-zinc-300" : "text-zinc-700"}>{f}</span>
                      </li>
                    ))}
                  </ul>

                  <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer" className="w-full">
                    <Button
                      className={`w-full h-12 rounded-xl font-bold text-sm ${
                        plan.popular
                          ? "bg-indigo-600 hover:bg-indigo-500 text-white border-0"
                          : "bg-zinc-900 hover:bg-zinc-800 text-white"
                      }`}
                    >
                      {plan.cta}
                    </Button>
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Trust badges */}
      <section className="w-full py-12 bg-zinc-50 border-t border-b border-zinc-100 px-4">
        <div className="container max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="flex flex-col items-center gap-2">
            <Shield className="h-8 w-8 text-zinc-400" />
            <p className="font-semibold text-zinc-900">30-Day Money Back</p>
            <p className="text-sm text-muted-foreground">Full refund if you don't capture a lead in 30 days.</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Zap className="h-8 w-8 text-zinc-400" />
            <p className="font-semibold text-zinc-900">Live in 24 Hours</p>
            <p className="text-sm text-muted-foreground">We handle setup. Your AI is live within one business day.</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Star className="h-8 w-8 text-zinc-400" />
            <p className="font-semibold text-zinc-900">Cancel Anytime</p>
            <p className="text-sm text-muted-foreground">No contracts. Stop your subscription from PayPal instantly.</p>
          </div>
        </div>
      </section>

      {/* Testimonial pull */}
      <section className="w-full py-20 px-4 bg-white">
        <div className="container max-w-2xl mx-auto text-center">
          <div className="flex gap-0.5 justify-center mb-4">
            {Array(5).fill(0).map((_, i) => <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="text-xl font-medium text-zinc-900 leading-relaxed mb-6">
            "Botly booked 3 new lash clients in the first week. It pays for itself ten times over."
          </p>
          <div className="flex items-center justify-center gap-3">
            <div className="h-10 w-10 rounded-full bg-zinc-900 text-white flex items-center justify-center text-xs font-bold">SC</div>
            <div className="text-left">
              <p className="font-semibold text-sm">Sophie Clarke</p>
              <p className="text-xs text-muted-foreground">Lash Technician, Manchester</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="w-full py-20 bg-zinc-50 px-4">
        <div className="container max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-10">Pricing questions</h2>
          <div className="bg-white rounded-2xl border border-zinc-100 shadow-sm px-8">
            {faqs.map((f) => <FaqItem key={f.q} {...f} />)}
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="w-full py-20 bg-zinc-950 text-white px-4">
        <div className="container max-w-xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">Still unsure? Try the demo first.</h2>
          <p className="text-zinc-400 mb-8">Chat with the AI yourself before spending a penny.</p>
          <Link href="/demo">
            <Button size="lg" className="h-13 px-8 bg-white text-zinc-900 hover:bg-zinc-100 font-bold rounded-full">
              Try Live Demo — Free
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
