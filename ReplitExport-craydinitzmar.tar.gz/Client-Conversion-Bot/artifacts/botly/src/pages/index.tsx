import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { useCreateLead } from "@workspace/api-client-react";
import { convertReferral } from "@/hooks/use-referral";
import {
  ArrowRight, Bot, Zap, TrendingUp, Clock, Shield, Star,
  Check, MessageSquare, Users, BarChart2, ChevronDown, ChevronUp
} from "lucide-react";

const PAYPAL_URL = "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

const testimonials = [
  {
    name: "Sophie Clarke",
    role: "Lash Technician, Manchester",
    quote: "I was sceptical at first, but Botly booked 3 new clients in the first week alone. It handles all my enquiries while I'm with customers.",
    rating: 5,
    initials: "SC",
  },
  {
    name: "James Okafor",
    role: "Restaurant Owner, Birmingham",
    quote: "My AI rep handles 90% of customer enquiries — opening times, menu questions, reservations. My phone stopped ringing off the hook.",
    rating: 5,
    initials: "JO",
  },
  {
    name: "Maria Santos",
    role: "Business Coach, London",
    quote: "I was losing warm leads to slow replies. Now every visitor gets an instant response and my conversion rate has doubled in a month.",
    rating: 5,
    initials: "MS",
  },
];

const faqs = [
  {
    q: "How long does setup take?",
    a: "Your AI is live within 24 hours of signing up. We handle everything — no technical skills needed from you.",
  },
  {
    q: "Does it work on my existing website?",
    a: "Yes. One line of code added to your website activates the chat widget on every page. Works with Wix, Squarespace, WordPress, and custom sites.",
  },
  {
    q: "What happens if the AI can't answer a question?",
    a: "The AI will capture the customer's details and let them know you'll follow up — so you never lose a lead even on edge cases.",
  },
  {
    q: "Can I customise what the AI says?",
    a: "Absolutely. You add your own FAQ entries in the dashboard and the AI learns from them immediately.",
  },
  {
    q: "Is there a contract?",
    a: "No contract, no lock-in. Pay monthly and cancel anytime from your PayPal account.",
  },
];

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        let start = 0;
        const duration = 1800;
        const step = target / (duration / 16);
        const timer = setInterval(() => {
          start += step;
          if (start >= target) { setCount(target); clearInterval(timer); }
          else setCount(Math.floor(start));
        }, 16);
      }
    });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return <div ref={ref}>{count.toLocaleString()}{suffix}</div>;
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-zinc-200 last:border-0">
      <button
        className="w-full flex items-center justify-between py-5 text-left font-semibold text-zinc-900 hover:text-zinc-700 transition-colors"
        onClick={() => setOpen(!open)}
      >
        {q}
        {open ? <ChevronUp className="h-4 w-4 shrink-0 text-zinc-500" /> : <ChevronDown className="h-4 w-4 shrink-0 text-zinc-500" />}
      </button>
      {open && <p className="pb-5 text-muted-foreground text-sm leading-relaxed">{a}</p>}
    </div>
  );
}

export default function Home() {
  const [trialEmail, setTrialEmail] = useState("");
  const [trialName, setTrialName] = useState("");
  const [trialDone, setTrialDone] = useState(false);
  const createLead = useCreateLead();

  const handleTrialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialName.trim() || !trialEmail.trim()) return;
    createLead.mutate(
      { data: { name: trialName, email: trialEmail, sessionId: "trial-" + Date.now() } },
      { onSuccess: () => { setTrialDone(true); convertReferral(trialEmail, trialName); } }
    );
  };

  return (
    <div className="flex flex-col items-center">

      {/* Urgency Banner */}
      <div className="w-full bg-zinc-900 text-white text-center py-2.5 px-4 text-sm font-medium">
        <span className="text-yellow-400 font-bold">Launch offer:</span> First month free when you pay annually — limited time only.{" "}
        <Link href="/pricing" className="underline underline-offset-2 hover:text-zinc-300 transition-colors">See plans</Link>
      </div>

      {/* Hero */}
      <section className="w-full py-24 md:py-32 px-4 flex flex-col items-center text-center bg-black text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(99,102,241,0.15),transparent_60%)]" />
        <div className="container max-w-5xl relative z-10 flex flex-col items-center">
          <div className="inline-flex items-center rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-sm text-white backdrop-blur-sm mb-8">
            <span className="flex h-2 w-2 rounded-full bg-green-400 mr-2 animate-pulse" />
            500+ businesses live right now
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-6 leading-[1.08] max-w-4xl">
            Your AI Sales Rep<br />
            <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">Never Sleeps. Always Closes.</span>
          </h1>
          <p className="text-xl text-zinc-400 mb-10 max-w-2xl font-light leading-relaxed">
            Botly answers customer questions, captures leads, and pushes visitors to book or buy — 24/7, without you lifting a finger.
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto mb-12">
            <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
              <Button size="lg" className="w-full sm:w-auto text-base h-14 px-8 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-bold shadow-lg shadow-indigo-600/25">
                Get Started — From £20/mo <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <Link href="/demo" className="w-full sm:w-auto">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-base h-14 px-8 bg-transparent text-white border-white/20 hover:bg-white/10 rounded-full">
                Try Live Demo
              </Button>
            </Link>
          </div>
          <div className="flex flex-wrap justify-center gap-6 text-sm text-zinc-500">
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> No setup fees</span>
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> Cancel anytime</span>
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-400" /> Live in 24 hours</span>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="w-full bg-zinc-950 text-white py-12 px-4">
        <div className="container max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { label: "Businesses live", target: 500, suffix: "+" },
            { label: "Chats handled", target: 50000, suffix: "+" },
            { label: "Leads captured", target: 12400, suffix: "+" },
            { label: "Avg response time", target: 2, suffix: "s" },
          ].map((stat) => (
            <div key={stat.label}>
              <div className="text-3xl md:text-4xl font-extrabold text-indigo-400 mb-1">
                <AnimatedCounter target={stat.target} suffix={stat.suffix} />
              </div>
              <div className="text-sm text-zinc-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="w-full py-24 bg-white px-4">
        <div className="container max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Up and running in 3 steps</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">No developers. No complicated setup. Just results.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "1", icon: MessageSquare, title: "Sign up and pay", body: "Choose your plan and complete payment via PayPal. Takes under 2 minutes." },
              { step: "2", icon: Bot, title: "We build your AI", body: "Our team trains your assistant with your business details and FAQ knowledge base within 24 hours." },
              { step: "3", icon: TrendingUp, title: "Watch leads roll in", body: "Paste one line of code on your website and your AI starts capturing leads and closing sales immediately." },
            ].map(({ step, icon: Icon, title, body }) => (
              <div key={step} className="flex flex-col items-start p-8 rounded-2xl border border-zinc-100 bg-zinc-50 relative">
                <span className="absolute top-6 right-6 text-5xl font-black text-zinc-100 select-none leading-none">{step}</span>
                <div className="h-12 w-12 rounded-xl bg-zinc-900 text-white flex items-center justify-center mb-5">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold mb-2">{title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="w-full py-24 bg-zinc-50 px-4">
        <div className="container max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Built to convert, not just chat</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Every feature is designed to turn visitors into paying customers.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Clock, bg: "bg-zinc-900", title: "24/7 Instant Replies", body: "Never miss a lead again. Botly responds in seconds at 3am just as reliably as 3pm." },
              { icon: Zap, bg: "bg-indigo-600", title: "Buying Intent Detection", body: "Our AI spots when someone is ready to buy and seamlessly pushes them toward your payment link." },
              { icon: Users, bg: "bg-zinc-900", title: "Automatic Lead Capture", body: "Names, emails, and phone numbers collected and stored in your dashboard automatically." },
              { icon: BarChart2, bg: "bg-indigo-600", title: "Live Dashboard", body: "See every conversation, lead, and conversion metric in real time from one clean dashboard." },
              { icon: Bot, bg: "bg-zinc-900", title: "Custom AI Training", body: "Feed your AI your own FAQ answers and it instantly learns to represent your business." },
              { icon: Shield, bg: "bg-indigo-600", title: "Works on Any Site", body: "Paste one line of code and your AI goes live on Wix, Squarespace, WordPress, or custom HTML." },
            ].map(({ icon: Icon, bg, title, body }) => (
              <div key={title} className="bg-white p-7 rounded-2xl shadow-sm border border-zinc-100 flex flex-col items-start hover:-translate-y-1 transition-transform">
                <div className={`h-11 w-11 rounded-lg ${bg} text-white flex items-center justify-center mb-5`}>
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold mb-2">{title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="w-full py-24 bg-white px-4">
        <div className="container max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Small businesses. Real results.</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">From beauty salons to coaches — Botly works for any business that talks to customers.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="flex flex-col p-7 rounded-2xl border border-zinc-100 bg-zinc-50 shadow-sm">
                <div className="flex gap-0.5 mb-4">
                  {Array(t.rating).fill(0).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-zinc-800 text-sm leading-relaxed mb-5 flex-1">"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-zinc-900 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    {t.initials}
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-zinc-900">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Free Trial CTA */}
      <section className="w-full py-24 px-4 bg-zinc-950 text-white">
        <div className="container max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center rounded-full border border-white/20 bg-white/5 px-3 py-1 text-sm mb-6">
            <span className="flex h-2 w-2 rounded-full bg-green-400 mr-2" /> 7-day free trial — no card needed
          </div>
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Try Botly free for 7 days
          </h2>
          <p className="text-zinc-400 text-lg mb-10">
            Enter your details and we'll get your AI set up within 24 hours. No payment until you're happy.
          </p>
          {trialDone ? (
            <div className="bg-white/10 rounded-2xl p-8 border border-white/10">
              <p className="text-2xl font-bold mb-2">You're in!</p>
              <p className="text-zinc-400 mb-6">We'll email you within 24 hours to set everything up. Ready to skip the queue?</p>
              <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold h-14 px-8 rounded-full">
                  Activate My Plan Now <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </a>
            </div>
          ) : (
            <form onSubmit={handleTrialSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
              <Input
                placeholder="Your name"
                value={trialName}
                onChange={(e) => setTrialName(e.target.value)}
                className="h-14 rounded-xl bg-white/10 border-white/20 text-white placeholder:text-zinc-500 focus-visible:ring-indigo-500"
                required
              />
              <Input
                type="email"
                placeholder="Your email"
                value={trialEmail}
                onChange={(e) => setTrialEmail(e.target.value)}
                className="h-14 rounded-xl bg-white/10 border-white/20 text-white placeholder:text-zinc-500 focus-visible:ring-indigo-500"
                required
              />
              <Button
                type="submit"
                disabled={createLead.isPending}
                className="h-14 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shrink-0"
              >
                {createLead.isPending ? "..." : "Start Free"}
              </Button>
            </form>
          )}
        </div>
      </section>

      {/* Guarantee */}
      <section className="w-full py-16 px-4 bg-white border-t border-zinc-100">
        <div className="container max-w-3xl mx-auto flex flex-col md:flex-row items-center gap-8 text-center md:text-left">
          <div className="h-20 w-20 rounded-full bg-zinc-900 text-white flex items-center justify-center shrink-0 mx-auto md:mx-0">
            <Shield className="h-9 w-9" />
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-2">30-Day Money Back Guarantee</h3>
            <p className="text-muted-foreground leading-relaxed">
              If Botly doesn't capture a single lead in your first 30 days, we'll refund you in full. No questions asked. We're that confident in what we've built.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="w-full py-24 bg-zinc-50 px-4">
        <div className="container max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-12">Common questions</h2>
          <div className="bg-white rounded-2xl border border-zinc-100 shadow-sm px-8">
            {faqs.map((faq) => <FaqItem key={faq.q} {...faq} />)}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="w-full py-24 px-4 bg-black text-white">
        <div className="container max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">Ready to grow on autopilot?</h2>
          <p className="text-xl text-zinc-400 mb-10 max-w-xl mx-auto">
            Join 500+ businesses using Botly to capture leads and close sales around the clock.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="h-14 px-10 text-lg bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-bold shadow-lg">
                Get Started Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <Link href="/pricing">
              <Button size="lg" variant="outline" className="h-14 px-10 text-lg text-white border-white/20 bg-transparent hover:bg-white/10 rounded-full">
                View Pricing
              </Button>
            </Link>
          </div>
          <p className="text-zinc-600 text-sm mt-6">From £20/month. Cancel anytime. 30-day guarantee.</p>
        </div>
      </section>

    </div>
  );
}
