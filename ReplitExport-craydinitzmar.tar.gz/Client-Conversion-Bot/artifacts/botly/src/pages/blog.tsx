import { Link } from "wouter";
import { ArrowRight, Clock, Tag } from "lucide-react";

const ARTICLES = [
  {
    slug: "ai-chatbot-small-business",
    title: "Why Every Small Business Needs an AI Chatbot in 2025",
    excerpt: "Customers expect instant replies at 2am on a Sunday. Here's how AI chat lets small businesses punch above their weight and never miss a lead.",
    category: "Growth",
    readTime: "5 min read",
    date: "May 2025",
  },
  {
    slug: "lash-tech-booking-automation",
    title: "How Lash Techs Are Filling Their Books Automatically",
    excerpt: "Stop losing bookings to DM lag. Discover how beauty professionals are using AI to collect appointments, answer FAQs, and follow up — while they're with a client.",
    category: "Beauty & Wellness",
    readTime: "4 min read",
    date: "May 2025",
  },
  {
    slug: "restaurant-customer-support-ai",
    title: "The Restaurant Owner's Guide to AI Customer Support",
    excerpt: "Opening times, menu queries, reservation requests — your AI handles it all, so your front-of-house team can focus on the guest in front of them.",
    category: "Hospitality",
    readTime: "6 min read",
    date: "April 2025",
  },
  {
    slug: "convert-website-visitors",
    title: "5 Ways to Convert More Website Visitors Without Spending More on Ads",
    excerpt: "Most small business websites lose 95% of visitors without a single reply. These five proven tactics — starting with live chat — change that overnight.",
    category: "Conversion",
    readTime: "7 min read",
    date: "April 2025",
  },
  {
    slug: "business-coach-lead-capture",
    title: "How Business Coaches Are Capturing 3x More Discovery Call Requests",
    excerpt: "A coach's biggest asset is their time. Learn how an AI-powered chat widget qualifies leads and books discovery calls while you sleep.",
    category: "Coaching",
    readTime: "5 min read",
    date: "March 2025",
  },
  {
    slug: "ecommerce-ai-support",
    title: "Ecommerce Support Without the Support Team",
    excerpt: "Order status, return policies, product questions — AI handles tier-1 support instantly and escalates the rest, cutting your support load by 80%.",
    category: "Ecommerce",
    readTime: "6 min read",
    date: "March 2025",
  },
];

const ARTICLE_CONTENT: Record<string, { body: string }> = {
  "ai-chatbot-small-business": {
    body: `Every second a customer waits for a reply is a second they spend on your competitor's website. Research consistently shows that responding within 5 minutes makes you 100 times more likely to convert a lead — yet most small businesses take hours, or don't reply at all.

**The 24/7 expectation**

Your customers are browsing on their lunch break, after their kids go to bed, and on Sunday mornings. They are not waiting for your business hours. An AI chatbot works every hour of every day without holiday pay, sick days, or slow mornings.

**What a good AI chatbot does for your business**

A well-configured chatbot does far more than answer FAQs. It captures leads when you are offline, detects buying signals and nudges visitors towards your payment page, books appointments, and flags complex queries for human follow-up. Every conversation is logged so you can see exactly what your customers are asking.

**The setup myth**

Many small business owners assume a chatbot takes weeks to set up and requires a developer. Botly goes live within 24 hours. You add one line of code to your website — works on Wix, Squarespace, WordPress, Shopify — and train it by adding your FAQs in plain English.

**The ROI is immediate**

If your average client is worth £200 and your chatbot captures even one extra lead per week that would otherwise have bounced, that is over £10,000 in additional revenue per year — for less than £100/month.

Start your free trial today and see your first AI-captured lead within 48 hours.`,
  },
  "lash-tech-booking-automation": {
    body: `As a lash technician, your hands are full — literally. While you are perfecting a client's lashes, potential customers are messaging your Instagram, checking your website, and moving on when they don't get an instant reply.

**The booking gap**

The gap between a customer's interest and your reply is where you lose money. Studies show 78% of customers book with the first business that responds. If that is a competitor, they are gone.

**How AI booking collection works**

When a visitor lands on your site and types "do you have availability next week?", your AI does not just answer — it starts collecting booking details conversationally. Service wanted. Preferred date. Preferred time. Name and contact. By the time you finish with your current client, a fully structured appointment request is waiting in your dashboard.

**Beyond bookings**

The AI also handles your most common questions: pricing, aftercare instructions, what to do before an appointment, payment methods. Every answer is pulled from your own FAQ knowledge base, so the information is always accurate and on-brand.

**One line of code**

Add the Botly widget to your Linktree, your website, or your booking page. It works everywhere. No monthly IT bills, no complicated setup.`,
  },
};

interface ArticlePageProps { slug: string }

function ArticlePage({ slug }: ArticlePageProps) {
  const article = ARTICLES.find((a) => a.slug === slug);
  const content = ARTICLE_CONTENT[slug];
  if (!article) return null;

  const paragraphs = (content?.body ?? article.excerpt).split("\n\n");

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-2xl mx-auto px-6 py-16">
        <Link href="/blog" className="inline-flex items-center gap-1.5 text-sm text-zinc-500 hover:text-zinc-900 mb-10 transition-colors">
          <ArrowRight className="h-3.5 w-3.5 rotate-180" /> Back to Blog
        </Link>
        <div className="flex items-center gap-3 mb-4">
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">{article.category}</span>
          <span className="text-xs text-zinc-400 flex items-center gap-1"><Clock className="h-3 w-3" />{article.readTime}</span>
          <span className="text-xs text-zinc-400">{article.date}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-zinc-900 mb-6 leading-tight">{article.title}</h1>
        <p className="text-lg text-zinc-500 mb-10 leading-relaxed">{article.excerpt}</p>
        <div className="prose prose-zinc max-w-none">
          {paragraphs.map((p, i) => {
            if (p.startsWith("**") && p.endsWith("**")) {
              return <h2 key={i} className="text-xl font-bold text-zinc-900 mt-8 mb-3">{p.replace(/\*\*/g, "")}</h2>;
            }
            const parts = p.split(/(\*\*[^*]+\*\*)/g);
            return (
              <p key={i} className="text-zinc-600 leading-relaxed mb-5">
                {parts.map((part, j) =>
                  part.startsWith("**") ? <strong key={j} className="font-semibold text-zinc-800">{part.replace(/\*\*/g, "")}</strong> : part
                )}
              </p>
            );
          })}
        </div>
        <div className="mt-12 p-8 bg-zinc-900 rounded-2xl text-center">
          <p className="text-white font-bold text-xl mb-2">Ready to capture more leads?</p>
          <p className="text-zinc-400 mb-6 text-sm">Start your free trial. Your AI is live within 24 hours.</p>
          <a href="/pricing" className="inline-block bg-white text-zinc-900 font-semibold px-6 py-3 rounded-xl text-sm hover:bg-zinc-100 transition-colors">
            Start Free Trial
          </a>
        </div>
      </div>
    </div>
  );
}

interface BlogProps { slug?: string }

export default function Blog({ slug }: BlogProps) {
  if (slug) return <ArticlePage slug={slug} />;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-zinc-900 text-white py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-widest uppercase text-indigo-400 mb-4 block">Botly Blog</span>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">
            Grow your small business<br className="hidden sm:block" /> with AI
          </h1>
          <p className="text-zinc-400 text-lg max-w-xl mx-auto">
            Practical guides, tips, and case studies for salons, restaurants, coaches, and ecommerce stores.
          </p>
        </div>
      </div>

      {/* Articles */}
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {ARTICLES.map((article) => (
            <Link key={article.slug} href={`/blog/${article.slug}`}
              className="group flex flex-col border border-zinc-200 rounded-2xl overflow-hidden hover:border-indigo-300 hover:shadow-md transition-all">
              <div className="bg-gradient-to-br from-zinc-900 to-zinc-800 h-36 flex items-center justify-center p-6">
                <p className="text-white text-sm font-semibold text-center leading-snug">{article.title}</p>
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 flex items-center gap-1">
                    <Tag className="h-2.5 w-2.5" />{article.category}
                  </span>
                  <span className="text-xs text-zinc-400 flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{article.readTime}</span>
                </div>
                <p className="text-zinc-600 text-sm leading-relaxed flex-1">{article.excerpt}</p>
                <div className="mt-4 flex items-center gap-1 text-indigo-600 text-sm font-semibold group-hover:gap-2 transition-all">
                  Read more <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-zinc-50 border-t border-zinc-200 py-16 px-6 text-center">
        <p className="text-zinc-900 font-bold text-2xl mb-2">Ready to put your customer support on autopilot?</p>
        <p className="text-zinc-500 mb-6">Join small businesses already using Botly to capture leads 24/7.</p>
        <a href="/pricing" className="inline-block bg-zinc-900 text-white font-semibold px-8 py-3.5 rounded-xl text-sm hover:bg-zinc-700 transition-colors">
          Start your free trial
        </a>
      </div>
    </div>
  );
}
