import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Bot, Zap, Star, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const BENEFITS = [
  "AI chatbot live on your website within 24 hours",
  "Captures leads and appointment requests automatically",
  "Sends you email alerts for new bookings and handoffs",
  "Answers customer questions 24/7 using your own FAQ",
  "No contract — cancel anytime",
];

export default function FreeTrial() {
  const [step, setStep] = useState<"form" | "success">("form");
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", businessName: "", industry: "" });
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) return;
    setLoading(true);
    try {
      await fetch(`${import.meta.env.BASE_URL}api/leads`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          message: `Free trial signup — Business: ${form.businessName || "not provided"}, Industry: ${form.industry || "not provided"}`,
          sessionId: `trial-${Date.now()}`,
        }),
      });
      setStep("success");
    } catch {
      toast({ title: "Something went wrong", description: "Please try again or contact us.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-zinc-900 py-20 px-6 text-center text-white">
        <div className="inline-flex items-center gap-2 bg-indigo-600/20 border border-indigo-500/30 rounded-full px-4 py-1.5 text-indigo-300 text-xs font-semibold mb-6">
          <Zap className="h-3.5 w-3.5" /> 7-day free trial — no card required
        </div>
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">
          Try Botly free<br className="hidden sm:block" /> for 7 days
        </h1>
        <p className="text-zinc-400 text-lg max-w-lg mx-auto">
          Your AI customer support assistant, live on your website within 24 hours. No risk, no commitment.
        </p>
        <div className="flex items-center justify-center gap-1 mt-6">
          {Array(5).fill(0).map((_, i) => <Star key={i} className="h-4 w-4 text-amber-400 fill-amber-400" />)}
          <span className="ml-2 text-zinc-400 text-sm">Loved by 500+ small businesses</span>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-16 grid lg:grid-cols-2 gap-12 items-start">
        {/* Benefits */}
        <div>
          <h2 className="text-2xl font-bold text-zinc-900 mb-6">What you get in your free trial</h2>
          <ul className="space-y-4 mb-10">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-start gap-3">
                <div className="h-5 w-5 rounded-full bg-indigo-600 flex items-center justify-center shrink-0 mt-0.5">
                  <Check className="h-3 w-3 text-white" />
                </div>
                <span className="text-zinc-700">{b}</span>
              </li>
            ))}
          </ul>

          <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-6">
            <div className="flex gap-3 mb-3">
              <div className="h-9 w-9 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm shrink-0">SC</div>
              <div>
                <p className="font-semibold text-sm text-zinc-900">Sophie Clarke</p>
                <p className="text-xs text-zinc-500">Lash Technician, Manchester</p>
              </div>
            </div>
            <p className="text-zinc-600 text-sm italic leading-relaxed">
              "Botly booked 3 new clients in the first week alone. The trial was risk-free so I had nothing to lose — I wish I'd started sooner."
            </p>
            <div className="flex gap-0.5 mt-3">
              {Array(5).fill(0).map((_, i) => <Star key={i} className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />)}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-3 gap-4">
            {[["24h", "Setup time"], ["24/7", "Always live"], ["0p", "No card needed"]].map(([val, label]) => (
              <div key={label} className="text-center p-4 bg-white border border-zinc-200 rounded-xl">
                <div className="text-2xl font-bold text-zinc-900">{val}</div>
                <div className="text-xs text-zinc-500 mt-1">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Form */}
        <div className="bg-white border border-zinc-200 rounded-2xl p-8 shadow-sm">
          {step === "success" ? (
            <div className="text-center py-8">
              <div className="h-14 w-14 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-5">
                <Bot className="h-7 w-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-zinc-900 mb-2">You're in!</h3>
              <p className="text-zinc-500 mb-6 text-sm leading-relaxed">
                Check your inbox — we'll send you everything you need to get your AI live within 24 hours.
                <br /><br />
                In the meantime, head to your dashboard to configure your chatbot.
              </p>
              <a href="/dashboard" className="inline-flex items-center gap-2 bg-zinc-900 text-white font-semibold px-6 py-3 rounded-xl text-sm hover:bg-zinc-700 transition-colors">
                Go to dashboard <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          ) : (
            <>
              <h3 className="text-xl font-bold text-zinc-900 mb-1">Start your free trial</h3>
              <p className="text-zinc-500 text-sm mb-6">No card required. Cancel anytime.</p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1.5 block">Your name</label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Sarah Jones" required />
                </div>
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1.5 block">Email address</label>
                  <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="sarah@yourbusiness.com" required />
                </div>
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1.5 block">Business name</label>
                  <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} placeholder="Glamour Lash Studio" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1.5 block">Industry</label>
                  <select value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })}
                    className="w-full border border-zinc-200 rounded-lg px-3 py-2 text-sm text-zinc-700 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="">Select your industry</option>
                    <option>Beauty & Lashes</option>
                    <option>Hair & Barbering</option>
                    <option>Restaurants & Hospitality</option>
                    <option>Business Coaching</option>
                    <option>Ecommerce</option>
                    <option>Health & Wellness</option>
                    <option>Other</option>
                  </select>
                </div>
                <Button type="submit" disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-xl">
                  {loading ? "Starting trial…" : "Start my free trial"}
                </Button>
                <p className="text-xs text-zinc-400 text-center">No card required. 7 days free, then from £20/mo.</p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
