import { useState } from "react";
import { useGetFaqs, useCreateFaq, useUpdateFaq, useDeleteFaq } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Plus, BookOpen } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

type FaqItem = { id: number; question: string; answer: string; category: string | null };

function FaqDialog({
  open,
  onClose,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  initial?: FaqItem | null;
}) {
  const [question, setQuestion] = useState(initial?.question ?? "");
  const [answer, setAnswer] = useState(initial?.answer ?? "");
  const [category, setCategory] = useState(initial?.category ?? "General");
  const queryClient = useQueryClient();
  const createMutation = useCreateFaq();
  const updateMutation = useUpdateFaq();

  const handleSubmit = async () => {
    if (!question.trim() || !answer.trim()) return;
    if (initial) {
      await updateMutation.mutateAsync({ id: initial.id, data: { question, answer, category } });
    } else {
      await createMutation.mutateAsync({ data: { question, answer, category } });
    }
    queryClient.invalidateQueries({ queryKey: ["getGetFaqs"] });
    onClose();
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? "Edit FAQ" : "Add FAQ Entry"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Question</Label>
            <Input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="What would a customer ask?" />
          </div>
          <div className="space-y-1.5">
            <Label>Answer</Label>
            <Textarea value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="How would you answer?" rows={4} />
          </div>
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="e.g. Pricing, Bookings..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isPending}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isPending || !question.trim() || !answer.trim()} className="bg-zinc-900 text-white hover:bg-zinc-800">
            {isPending ? "Saving..." : initial ? "Save Changes" : "Add Entry"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function DashboardFaq() {
  const { data: faqs, isLoading } = useGetFaqs();
  const deleteMutation = useDeleteFaq();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<FaqItem | null>(null);

  const handleDelete = (id: number) => {
    if (confirm("Delete this FAQ entry?")) {
      deleteMutation.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ["getGetFaqs"] }),
      });
    }
  };

  const openEdit = (faq: FaqItem) => {
    setEditing(faq);
    setDialogOpen(true);
  };

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">FAQ Knowledge Base</h1>
          <p className="text-muted-foreground mt-1">Train your AI with answers to common questions.</p>
        </div>
        <Button onClick={openCreate} className="bg-zinc-900 text-white hover:bg-zinc-800 gap-2">
          <Plus className="h-4 w-4" /> Add Entry
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array(4).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full rounded-xl" />
          ))}
        </div>
      ) : (faqs ?? []).length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <BookOpen className="h-10 w-10 text-zinc-300 mb-3" />
          <p className="text-muted-foreground">No FAQ entries yet. Add your first one to train your AI.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {(faqs ?? []).map((faq) => (
            <Card key={faq.id} className="rounded-xl border-zinc-200/60 shadow-sm group">
              <CardContent className="pt-5 pb-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                      <p className="font-semibold text-zinc-900">{faq.question}</p>
                      {faq.category && (
                        <Badge variant="outline" className="text-xs shrink-0">{faq.category}</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-zinc-900" onClick={() => openEdit(faq as FaqItem)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(faq.id)} disabled={deleteMutation.isPending}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <FaqDialog
        open={dialogOpen}
        onClose={() => { setDialogOpen(false); setEditing(null); }}
        initial={editing}
      />
    </div>
  );
}
