import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Calendar, CheckCircle2, XCircle, Clock, User, Phone, Mail, Scissors
} from "lucide-react";
import { format } from "date-fns";

interface Booking {
  id: number;
  sessionId: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  service: string | null;
  preferredDate: string | null;
  preferredTime: string | null;
  notes: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
}

interface BookingsData {
  bookings: Booking[];
  total: number;
  pending: number;
  confirmed: number;
  cancelled: number;
}

const STATUS_STYLES: Record<string, string> = {
  pending: "border-amber-300 text-amber-700 bg-amber-50",
  confirmed: "border-green-300 text-green-700 bg-green-50",
  cancelled: "border-red-300 text-red-700 bg-red-50",
};

function StatusButton({ id, current, onUpdate }: { id: number; current: string; onUpdate: () => void }) {
  const [loading, setLoading] = useState(false);

  const updateStatus = async (status: string) => {
    setLoading(true);
    await fetch(`${import.meta.env.BASE_URL}api/bookings/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setLoading(false);
    onUpdate();
  };

  if (current === "pending") return (
    <div className="flex gap-2">
      <Button size="sm" disabled={loading} onClick={() => updateStatus("confirmed")}
        className="h-8 bg-green-600 hover:bg-green-700 text-white text-xs rounded-lg gap-1">
        <CheckCircle2 className="h-3.5 w-3.5" /> Confirm
      </Button>
      <Button size="sm" variant="outline" disabled={loading} onClick={() => updateStatus("cancelled")}
        className="h-8 text-xs rounded-lg gap-1 border-red-200 text-red-600 hover:bg-red-50">
        <XCircle className="h-3.5 w-3.5" /> Cancel
      </Button>
    </div>
  );
  if (current === "confirmed") return (
    <Button size="sm" variant="outline" disabled={loading} onClick={() => updateStatus("cancelled")}
      className="h-8 text-xs rounded-lg gap-1 border-red-200 text-red-600 hover:bg-red-50">
      <XCircle className="h-3.5 w-3.5" /> Cancel
    </Button>
  );
  return (
    <Button size="sm" variant="outline" disabled={loading} onClick={() => updateStatus("pending")}
      className="h-8 text-xs rounded-lg gap-1">
      Restore
    </Button>
  );
}

export default function DashboardBookings() {
  const [data, setData] = useState<BookingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "pending" | "confirmed" | "cancelled">("all");

  const load = () => {
    fetch(`${import.meta.env.BASE_URL}api/bookings`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const filtered = (data?.bookings ?? []).filter((b) =>
    filter === "all" ? true : b.status === filter
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Bookings</h1>
        <p className="text-muted-foreground mt-1">
          Appointment requests collected by your AI — 24 hours a day.
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-5 sm:grid-cols-4">
        {loading ? (
          Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          [
            { icon: Calendar, label: "Total Requests", value: data?.total ?? 0, color: "text-indigo-500" },
            { icon: Clock, label: "Pending", value: data?.pending ?? 0, color: "text-amber-500" },
            { icon: CheckCircle2, label: "Confirmed", value: data?.confirmed ?? 0, color: "text-green-500" },
            { icon: XCircle, label: "Cancelled", value: data?.cancelled ?? 0, color: "text-red-500" },
          ].map(({ icon: Icon, label, value, color }) => (
            <Card key={label} className="rounded-xl border-zinc-200/60 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between pb-2 bg-zinc-50/50 border-b">
                <CardTitle className="text-sm font-medium text-zinc-600">{label}</CardTitle>
                <Icon className={`h-4 w-4 ${color}`} />
              </CardHeader>
              <CardContent className="pt-5">
                <div className="text-3xl font-bold tracking-tight text-zinc-900">{value}</div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2 flex-wrap">
        {(["all", "pending", "confirmed", "cancelled"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors border capitalize ${
              filter === f ? "bg-zinc-900 text-white border-zinc-900" : "bg-white text-zinc-500 border-zinc-200 hover:border-zinc-400"
            }`}>
            {f}
            {f !== "all" && data && (
              <span className="ml-1.5 text-xs opacity-60">
                ({f === "pending" ? data.pending : f === "confirmed" ? data.confirmed : data.cancelled})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Table */}
      <Card className="rounded-2xl border-zinc-200/60 shadow-sm overflow-hidden">
        <CardHeader>
          <CardTitle className="text-lg">Appointment Requests</CardTitle>
          <CardDescription>Collected automatically from chat conversations on your website.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-zinc-50/80">
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Preferred Date / Time</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Received</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading…</TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Calendar className="h-10 w-10 text-zinc-300 mb-3" />
                      <p>No {filter === "all" ? "" : filter} bookings yet.</p>
                      <p className="text-sm mt-1 max-w-xs">When a visitor asks to book via the chat widget, it appears here automatically.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((b) => (
                  <TableRow key={b.id} className="hover:bg-zinc-50/50">
                    <TableCell>
                      <div className="space-y-0.5">
                        {b.name && (
                          <div className="flex items-center gap-1.5 text-sm font-medium text-zinc-900">
                            <User className="h-3.5 w-3.5 text-zinc-400 shrink-0" /> {b.name}
                          </div>
                        )}
                        {b.email && (
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Mail className="h-3 w-3 shrink-0" /> {b.email}
                          </div>
                        )}
                        {b.phone && (
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Phone className="h-3 w-3 shrink-0" /> {b.phone}
                          </div>
                        )}
                        {!b.name && !b.email && !b.phone && (
                          <span className="text-sm text-zinc-400">No contact info</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {b.service ? (
                        <div className="flex items-center gap-1.5 text-sm font-medium text-zinc-700">
                          <Scissors className="h-3.5 w-3.5 text-zinc-400 shrink-0" /> {b.service}
                        </div>
                      ) : <span className="text-zinc-400 text-sm">Not specified</span>}
                      {b.notes && <p className="text-xs text-muted-foreground mt-0.5 max-w-[160px] truncate" title={b.notes}>{b.notes}</p>}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-zinc-700">
                        {b.preferredDate && <div className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5 text-zinc-400 shrink-0" />{b.preferredDate}</div>}
                        {b.preferredTime && <div className="flex items-center gap-1.5 mt-0.5"><Clock className="h-3.5 w-3.5 text-zinc-400 shrink-0" />{b.preferredTime}</div>}
                        {!b.preferredDate && !b.preferredTime && <span className="text-zinc-400">Not specified</span>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={STATUS_STYLES[b.status] ?? "border-zinc-300 text-zinc-500"}>
                        {b.status.charAt(0).toUpperCase() + b.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                      {format(new Date(b.createdAt), "MMM d, HH:mm")}
                    </TableCell>
                    <TableCell>
                      <StatusButton id={b.id} current={b.status} onUpdate={load} />
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
