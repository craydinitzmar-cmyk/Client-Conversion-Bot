import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Mail, Send, Clock, AlertCircle } from "lucide-react";
import { format } from "date-fns";

interface QueueItem {
  id: number;
  toName: string;
  toEmail: string;
  subject: string;
  sequenceStep: number;
  status: string;
  scheduledAt: string;
  sentAt: string | null;
  errorMessage: string | null;
  createdAt: string;
}

interface QueueData {
  items: QueueItem[];
  total: number;
  sent: number;
  pending: number;
  failed: number;
}

const STEP_LABELS: Record<number, string> = {
  1: "Welcome",
  2: "Social Proof",
  3: "Urgency",
};

const STATUS_STYLES: Record<string, string> = {
  sent: "border-green-300 text-green-700 bg-green-50",
  pending: "border-amber-300 text-amber-700 bg-amber-50",
  failed: "border-red-300 text-red-700 bg-red-50",
};

export default function DashboardEmailQueue() {
  const [data, setData] = useState<QueueData | null>(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    fetch(`${import.meta.env.BASE_URL}api/email-queue`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 30_000);
    return () => clearInterval(id);
  }, []);

  const statCards = [
    { icon: Mail, label: "Total Emails", value: data?.total ?? 0 },
    { icon: Send, label: "Sent", value: data?.sent ?? 0, color: "text-green-500" },
    { icon: Clock, label: "Pending", value: data?.pending ?? 0, color: "text-amber-500" },
    { icon: AlertCircle, label: "Failed", value: data?.failed ?? 0, color: "text-red-500" },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Email Sequences</h1>
        <p className="text-muted-foreground mt-1">
          Automated 3-part welcome series sent to every lead. Refreshes every 30s.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-4">
        {loading
          ? Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
          : statCards.map(({ icon: Icon, label, value, color }) => (
            <Card key={label} className="rounded-xl border-zinc-200/60 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between pb-2 bg-zinc-50/50 border-b">
                <CardTitle className="text-sm font-medium text-zinc-600">{label}</CardTitle>
                <Icon className={`h-4 w-4 ${color ?? "text-indigo-500"}`} />
              </CardHeader>
              <CardContent className="pt-5">
                <div className="text-3xl font-bold tracking-tight text-zinc-900">{value}</div>
              </CardContent>
            </Card>
          ))}
      </div>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm overflow-hidden">
        <CardHeader>
          <CardTitle className="text-lg">Email Queue</CardTitle>
          <CardDescription>
            Every lead receives 3 emails: immediately, after 24 hours, and after 48 hours.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-zinc-50/80">
              <TableRow>
                <TableHead>Recipient</TableHead>
                <TableHead>Step</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Scheduled</TableHead>
                <TableHead>Sent</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : (data?.items ?? []).length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Mail className="h-10 w-10 text-zinc-300 mb-3" />
                      No emails in the queue yet. Emails are queued when a new lead signs up.
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                (data?.items ?? []).map((item) => (
                  <TableRow key={item.id} className="hover:bg-zinc-50/50">
                    <TableCell>
                      <div className="text-sm font-medium text-zinc-900">{item.toName}</div>
                      <div className="text-xs text-muted-foreground">{item.toEmail}</div>
                    </TableCell>
                    <TableCell>
                      <span className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-700">
                        <span className="w-5 h-5 rounded-full bg-zinc-900 text-white text-[10px] font-bold flex items-center justify-center">
                          {item.sequenceStep}
                        </span>
                        {STEP_LABELS[item.sequenceStep] ?? `Step ${item.sequenceStep}`}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-zinc-700 max-w-[260px] block truncate" title={item.subject}>
                        {item.subject}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={STATUS_STYLES[item.status] ?? "border-zinc-300 text-zinc-500"}
                      >
                        {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                      </Badge>
                      {item.errorMessage && (
                        <p className="text-xs text-red-500 mt-0.5 max-w-[200px] truncate" title={item.errorMessage}>
                          {item.errorMessage}
                        </p>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                      {format(new Date(item.scheduledAt), "MMM d, HH:mm")}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                      {item.sentAt ? format(new Date(item.sentAt), "MMM d, HH:mm") : "—"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="rounded-2xl border border-zinc-100 bg-zinc-50 p-6">
        <h3 className="font-semibold text-zinc-900 mb-3">Sequence overview</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          {[
            { step: 1, label: "Welcome", delay: "Immediately", desc: "Confirms sign-up, explains next steps, CTA to activate plan via PayPal." },
            { step: 2, label: "Social Proof", delay: "After 24 hours", desc: "Stats, testimonials, and results from other businesses to build confidence." },
            { step: 3, label: "Urgency", delay: "After 48 hours", desc: "Final push — trial is almost up, don't lose momentum, hard PayPal CTA." },
          ].map(({ step, label, delay, desc }) => (
            <div key={step} className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-zinc-900 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                {step}
              </div>
              <div>
                <p className="font-semibold text-sm text-zinc-900">{label} <span className="text-zinc-400 font-normal">· {delay}</span></p>
                <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
