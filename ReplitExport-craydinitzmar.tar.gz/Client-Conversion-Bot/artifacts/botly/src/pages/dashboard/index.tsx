import { useGetStats, getGetStatsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, MessageSquare, Zap, Percent } from "lucide-react";

export default function DashboardOverview() {
  const { data: stats, isLoading } = useGetStats({ query: { queryKey: getGetStatsQueryKey() } });

  const statCards = [
    {
      title: "Total Leads",
      value: stats?.totalLeads ?? 0,
      icon: Users,
      description: "All time captured leads",
    },
    {
      title: "Chat Sessions",
      value: stats?.totalSessions ?? 0,
      icon: MessageSquare,
      description: "Total conversations held",
    },
    {
      title: "Buying Intent",
      value: stats?.intentDetectedCount ?? 0,
      icon: Zap,
      description: "Sessions showing interest",
    },
    {
      title: "Conversion Rate",
      value: `${((stats?.conversionRate ?? 0) * 100).toFixed(1)}%`,
      icon: Percent,
      description: "Intent to lead conversion",
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Overview</h1>
        <p className="text-muted-foreground mt-1">Here is how your AI sales rep is performing.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {isLoading
          ? Array(4).fill(0).map((_, i) => (
              <Card key={i} className="rounded-xl border-zinc-200/60 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-4 rounded-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-3 w-32" />
                </CardContent>
              </Card>
            ))
          : statCards.map((card, i) => (
              <Card key={i} className="rounded-xl border-zinc-200/60 shadow-sm overflow-hidden group">
                <CardHeader className="flex flex-row items-center justify-between pb-2 bg-zinc-50/50 border-b">
                  <CardTitle className="text-sm font-medium text-zinc-600">{card.title}</CardTitle>
                  <card.icon className="h-4 w-4 text-accent" />
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold tracking-tight text-zinc-900 group-hover:text-accent transition-colors">{card.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{card.description}</p>
                </CardContent>
              </Card>
            ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="rounded-xl border-zinc-200/60 shadow-sm">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
              <Zap className="h-8 w-8 mb-4 text-zinc-300" />
              <p>Your AI is waiting for its next customer.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}