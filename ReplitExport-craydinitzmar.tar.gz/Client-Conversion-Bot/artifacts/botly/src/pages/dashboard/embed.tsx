import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Copy, Code2, Globe, Zap, Shield } from "lucide-react";

const SNIPPET = `<!-- Botly AI Chat Widget -->
<script src="https://botly.replit.app/api/widget.js" async></script>`;

function CopyBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="relative group rounded-xl overflow-hidden border border-zinc-200/60">
      <div className="bg-zinc-950 px-5 py-4">
        <pre className="text-sm text-zinc-300 font-mono leading-relaxed whitespace-pre-wrap break-all">
          {code}
        </pre>
      </div>
      <Button
        size="sm"
        variant="secondary"
        onClick={handleCopy}
        className="absolute top-3 right-3 h-8 gap-1.5 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border-zinc-700"
      >
        {copied ? (
          <><Check className="h-3 w-3 text-green-400" /> Copied</>
        ) : (
          <><Copy className="h-3 w-3" /> Copy</>
        )}
      </Button>
    </div>
  );
}

const steps = [
  {
    step: "1",
    title: "Copy the snippet",
    description: "Click the copy button above to grab your embed code.",
  },
  {
    step: "2",
    title: "Paste before </body>",
    description: "Open your website's HTML and paste the snippet just before the closing body tag.",
  },
  {
    step: "3",
    title: "Save and publish",
    description: "Publish your site. The Botly chat button will appear instantly on every page.",
  },
];

const features = [
  { icon: Zap, label: "Buying intent detection — shows PayPal link automatically" },
  { icon: Globe, label: "Works on any website — Wix, Squarespace, WordPress, custom HTML" },
  { icon: Shield, label: "Lead capture built in — collects name and email" },
  { icon: Code2, label: "One line of code — no developer needed" },
];

export default function DashboardEmbed() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Embed on Your Website</h1>
        <p className="text-muted-foreground mt-1">
          Add the Botly AI chat widget to any website with one line of code.
        </p>
      </div>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Your Embed Snippet</CardTitle>
            <Badge variant="outline" className="text-xs border-green-300 text-green-700 bg-green-50">
              Ready to use
            </Badge>
          </div>
          <CardDescription>
            Paste this into the HTML of any page you want Botly to appear on.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <CopyBlock code={SNIPPET} />
          <p className="text-xs text-muted-foreground">
            The script loads asynchronously — it will not slow down your website.
          </p>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">How to Install</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-5">
            {steps.map((s) => (
              <li key={s.step} className="flex gap-4">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-zinc-900 text-white text-sm font-bold flex items-center justify-center">
                  {s.step}
                </span>
                <div>
                  <p className="font-semibold text-zinc-900 text-sm">{s.title}</p>
                  <p className="text-sm text-muted-foreground mt-0.5">{s.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">What the Widget Does</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {features.map((f) => (
              <li key={f.label} className="flex items-start gap-3 text-sm">
                <f.icon className="h-4 w-4 text-zinc-500 mt-0.5 flex-shrink-0" />
                <span className="text-zinc-700">{f.label}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-zinc-900 bg-zinc-950 shadow-sm">
        <CardContent className="py-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex-1">
              <p className="font-semibold text-white">Want to see it live first?</p>
              <p className="text-sm text-zinc-400 mt-0.5">Visit the demo page to chat with the AI before adding it to your site.</p>
            </div>
            <a
              href="/demo"
              className="inline-flex items-center justify-center rounded-xl bg-white text-zinc-900 font-semibold text-sm px-5 py-2.5 hover:bg-zinc-100 transition-colors shrink-0"
            >
              Try the Demo
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
