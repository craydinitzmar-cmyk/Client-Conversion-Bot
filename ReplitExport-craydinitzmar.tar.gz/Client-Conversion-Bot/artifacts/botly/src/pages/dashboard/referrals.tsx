import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Gift, Users, TrendingUp } from "lucide-react";
import { format } from "date-fns";

interface AdminReferral {
  id: number;
  referrerEmail: string;
  code: string;
  referredEmail: string | null;
  referredName: string | null;
  status: string;
  reward: string;
  createdAt: string;
  convertedAt: string | null;
}

interface AdminStats {
  referrals: AdminReferral[];
  total: number;
  totalConverted: number;
}

export default function DashboardReferrals() {
  const [data, setData] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${import.meta.env.BASE_URL}api/referrals`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  const uniqueReferrers = data ? new Set(data.referrals.map((r) => r.referrerEmail)).size : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Referrals</h1>
        <p className="text-muted-foreground mt-1">Track who is spreading the word and earning free months.</p>
      </div>

      {/* Stats */}
      <div className="grid gap-5 sm:grid-cols-3">
        {loading ? (
          Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          [
            { icon: Users, label: "Active Referrers", value: uniqueReferrers },
            { icon: Gift, label: "Total Referral Links", value: data?.total ?? 0 },
            { icon: TrendingUp, label: "Converted Sign-ups", value: data?.totalConverted ?? 0 },
          ].map(({ icon: Icon, label, value }) => (
            <Card key={label} className="rounded-xl border-zinc-200/60 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between pb-2 bg-zinc-50/50 border-b">
                <CardTitle className="text-sm font-medium text-zinc-600">{label}</CardTitle>
                <Icon className="h-4 w-4 text-indigo-500" />
              </CardHeader>
              <CardContent className="pt-5">
                <div className="text-3xl font-bold tracking-tight text-zinc-900">{value}</div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Table */}
      <Card className="rounded-2xl border-zinc-200/60 shadow-sm overflow-hidden">
        <CardHeader>
          <CardTitle className="text-lg">All Referrals</CardTitle>
          <CardDescription>Every referral link created and its conversion status.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-zinc-50/80">
              <TableRow>
                <TableHead>Referrer</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Referred</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Reward</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading...</TableCell>
                </TableRow>
              ) : (data?.referrals ?? []).length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Gift className="h-10 w-10 text-zinc-300 mb-3" />
                      No referrals yet. Share the referral page link with your customers.
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                (data?.referrals ?? []).map((r) => (
                  <TableRow key={r.id} className="hover:bg-zinc-50/50">
                    <TableCell>
                      <span className="text-sm text-zinc-700">{r.referrerEmail}</span>
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-sm font-semibold text-zinc-900">{r.code}</span>
                    </TableCell>
                    <TableCell>
                      {r.referredName ? (
                        <div>
                          <div className="text-sm font-medium text-zinc-900">{r.referredName}</div>
                          {r.referredEmail && <div className="text-xs text-muted-foreground">{r.referredEmail}</div>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">Awaiting sign-up</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          r.status === "converted"
                            ? "border-green-300 text-green-700 bg-green-50"
                            : "border-zinc-300 text-zinc-500"
                        }
                      >
                        {r.status === "converted" ? "Converted" : "Pending"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {r.status === "converted" ? (
                        <span className="text-sm text-indigo-600 font-medium">{r.reward}</span>
                      ) : (
                        <span className="text-sm text-zinc-400">{r.reward}</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {format(new Date(r.createdAt), "MMM d, yyyy")}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
