import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertCircle, CheckCircle2, Clock, UserCheck, MessageSquare, ChevronDown, ChevronUp
} from "lucide-react";
import { format } from "date-fns";

interface Message { id: number; role: string; content: string; createdAt: string; }
interface Handoff {
  id: number;
  sessionId: string;
  flagReason: string;
  triggerMessage: string;
  status: string;
  flaggedAt: string;
  resolvedAt: string | null;
  resolvedNote: string | null;
  messages: Message[];
}
interface HandoffsData { handoffs: Handoff[]; total: number; pending: number; }

function TranscriptRow({ handoff, onResolved }: { handoff: Handoff; onResolved: () => void }) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [resolving, setResolving] = useState(false);

  const resolve = async () => {
    setResolving(true);
    await fetch(`${import.meta.env.BASE_URL}api/handoffs/${handoff.id}/resolve`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ note }),
    });
    setResolving(false);
    onResolved();
  };

  const isPending = handoff.status === "pending";

  return (
    <div className={`rounded-2xl border overflow-hidden transition-all ${isPending ? "border-amber-200 bg-amber-50/40" : "border-zinc-100 bg-white"}`}>
      {/* Header row */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-start gap-4 p-5 text-left hover:bg-zinc-50/80 transition-colors"
      >
        <div className="mt-0.5 shrink-0">
          {isPending
            ? <AlertCircle className="h-5 w-5 text-amber-500" />
            : <CheckCircle2 className="h-5 w-5 text-green-500" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="font-semibold text-sm text-zinc-900 font-mono">{handoff.sessionId.slice(0, 16)}…</span>
            <Badge variant="outline" className={isPending
              ? "border-amber-300 text-amber-700 bg-amber-50 text-xs"
              : "border-green-300 text-green-700 bg-green-50 text-xs"}>
              {isPending ? "Needs handoff" : "Resolved"}
            </Badge>
          </div>
          <p className="text-sm text-zinc-600 truncate max-w-xl">
            <span className="text-zinc-400 font-medium">Trigger: </span>"{handoff.triggerMessage}"
          </p>
          <p className="text-xs text-zinc-400 mt-1">
            {handoff.flagReason} &middot; Flagged {format(new Date(handoff.flaggedAt), "MMM d, HH:mm")}
            {handoff.resolvedAt && ` · Resolved ${format(new Date(handoff.resolvedAt), "MMM d, HH:mm")}`}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-zinc-400">{handoff.messages.length} msgs</span>
          {open ? <ChevronUp className="h-4 w-4 text-zinc-400" /> : <ChevronDown className="h-4 w-4 text-zinc-400" />}
        </div>
      </button>

      {/* Expanded transcript + resolve */}
      {open && (
        <div className="border-t border-zinc-100 px-5 pb-5 pt-4 space-y-4">
          {/* Transcript */}
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {handoff.messages.map((m) => (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
                  m.role === "user"
                    ? "bg-zinc-900 text-white"
                    : "bg-zinc-100 text-zinc-800"
                }`}>
                  <p>{m.content}</p>
                  <p className={`text-[10px] mt-1 ${m.role === "user" ? "text-zinc-400" : "text-zinc-500"}`}>
                    {format(new Date(m.createdAt), "HH:mm")}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Resolve */}
          {isPending && (
            <div className="border-t border-zinc-100 pt-4 space-y-3">
              <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wide">Mark as resolved</p>
              <Textarea
                placeholder="Optional note (e.g. 'Called customer back, booked appointment')"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="text-sm resize-none h-20 rounded-xl"
              />
              <Button
                onClick={resolve}
                disabled={resolving}
                className="h-10 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl text-sm font-semibold gap-2"
              >
                <UserCheck className="h-4 w-4" />
                {resolving ? "Saving…" : "Mark Resolved"}
              </Button>
            </div>
          )}

          {!isPending && handoff.resolvedNote && (
            <div className="border-t border-zinc-100 pt-4">
              <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wide mb-1">Resolution note</p>
              <p className="text-sm text-zinc-600">{handoff.resolvedNote}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function DashboardHandoffs() {
  const [data, setData] = useState<HandoffsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "pending" | "resolved">("pending");

  const load = () => {
    fetch(`${import.meta.env.BASE_URL}api/handoffs`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const filtered = (data?.handoffs ?? []).filter((h) =>
    filter === "all" ? true : h.status === filter
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Live Handoffs</h1>
        <p className="text-muted-foreground mt-1">
          Conversations where a customer asked for a human — flagged automatically by the AI.
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-5 sm:grid-cols-3">
        {loading ? (
          Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          [
            { icon: AlertCircle, label: "Needs Attention", value: data?.pending ?? 0, color: "text-amber-500" },
            { icon: CheckCircle2, label: "Resolved", value: (data?.total ?? 0) - (data?.pending ?? 0), color: "text-green-500" },
            { icon: MessageSquare, label: "Total Flagged", value: data?.total ?? 0, color: "text-indigo-500" },
          ].map(({ icon: Icon, label, value, color }) => (
            <Card key={label} className="rounded-xl border-zinc-200/60 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between pb-2 bg-zinc-50/50 border-b">
                <CardTitle className="text-sm font-medium text-zinc-600">{label}</CardTitle>
                <Icon className={`h-4 w-4 ${color}`} />
              </CardHeader>
              <CardContent className="pt-5">
                <div className="text-3xl font-bold tracking-tight text-zinc-900">{value}</div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2">
        {(["pending", "resolved", "all"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors border ${
              filter === f
                ? "bg-zinc-900 text-white border-zinc-900"
                : "bg-white text-zinc-500 border-zinc-200 hover:border-zinc-400"
            }`}
          >
            {f === "pending" ? "Needs Attention" : f === "resolved" ? "Resolved" : "All"}
          </button>
        ))}
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="rounded-2xl border-zinc-100 shadow-sm">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Clock className="h-10 w-10 text-zinc-300 mb-3" />
            <p className="text-zinc-500 font-medium">No {filter === "all" ? "" : filter} handoffs yet.</p>
            <p className="text-sm text-muted-foreground mt-1 max-w-sm">
              When a visitor asks to speak to a real person, the AI flags the conversation here automatically.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((h) => (
            <TranscriptRow key={h.id} handoff={h} onResolved={load} />
          ))}
        </div>
      )}

      {/* Explanation */}
      <Card className="rounded-2xl border-zinc-100 bg-zinc-50 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">How handoff detection works</CardTitle>
          <CardDescription>The AI monitors every message for signals that a human needs to step in.</CardDescription>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-4 text-sm">
          {[
            { label: "Human request", desc: "\"Speak to someone\", \"real person\", \"live agent\", \"manager\"" },
            { label: "Frustration signals", desc: "\"Complaint\", \"not happy\", \"that's wrong\", \"not helpful\", \"frustrated\"" },
            { label: "Urgent matters", desc: "\"Urgent\", \"emergency\", \"refund\", \"cancel\"" },
            { label: "What happens next", desc: "You receive an instant email alert with the full transcript. Mark it resolved here once handled." },
          ].map(({ label, desc }) => (
            <div key={label} className="flex gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
              <div>
                <p className="font-semibold text-zinc-900">{label}</p>
                <p className="text-zinc-500 text-xs mt-0.5 leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
