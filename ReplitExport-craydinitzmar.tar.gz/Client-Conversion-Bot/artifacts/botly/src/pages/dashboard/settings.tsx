import { useEffect, useState } from "react";
import { useGetSettings, useUpdateSettings } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink } from "lucide-react";

const PAYPAL_URL = "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

export default function DashboardSettings() {
  const { data: settings, isLoading } = useGetSettings();
  const updateMutation = useUpdateSettings();
  const queryClient = useQueryClient();

  const [form, setForm] = useState({
    businessName: "",
    greetingMessage: "",
    starterPrice: "",
    businessPrice: "",
    premiumPrice: "",
    starterDescription: "",
    businessDescription: "",
    premiumDescription: "",
  });

  useEffect(() => {
    if (settings) {
      setForm({
        businessName: settings.businessName ?? "",
        greetingMessage: settings.greetingMessage ?? "",
        starterPrice: settings.starterPrice ?? "£20/month",
        businessPrice: settings.businessPrice ?? "£50/month",
        premiumPrice: settings.premiumPrice ?? "£99/month",
        starterDescription: settings.starterDescription ?? "",
        businessDescription: settings.businessDescription ?? "",
        premiumDescription: settings.premiumDescription ?? "",
      });
    }
  }, [settings]);

  const handleSave = async () => {
    await updateMutation.mutateAsync({ data: form });
    queryClient.invalidateQueries({ queryKey: ["getGetSettings"] });
    toast({ title: "Settings saved", description: "Your configuration has been updated." });
  };

  if (isLoading) {
    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div>
          <Skeleton className="h-9 w-48 mb-2" />
          <Skeleton className="h-4 w-72" />
        </div>
        <Skeleton className="h-64 w-full rounded-2xl" />
        <Skeleton className="h-48 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure your AI assistant and pricing details.</p>
      </div>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Business Profile</CardTitle>
          <CardDescription>Personalise how your AI introduces itself to visitors.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-1.5">
            <Label>Business Name</Label>
            <Input
              value={form.businessName}
              onChange={(e) => setForm({ ...form, businessName: e.target.value })}
              placeholder="e.g. Lashes by Sophie"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Greeting Message</Label>
            <Textarea
              value={form.greetingMessage}
              onChange={(e) => setForm({ ...form, greetingMessage: e.target.value })}
              placeholder="e.g. Hi! I'm your AI assistant. How can I help you today?"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Pricing Plans</CardTitle>
          <CardDescription>Edit the plan labels shown on your pricing page.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {[
            { label: "Starter Plan", priceKey: "starterPrice", descKey: "starterDescription" },
            { label: "Business Plan", priceKey: "businessPrice", descKey: "businessDescription" },
            { label: "Premium Plan", priceKey: "premiumPrice", descKey: "premiumDescription" },
          ].map(({ label, priceKey, descKey }) => (
            <div key={priceKey} className="space-y-3">
              <p className="text-sm font-semibold text-zinc-800">{label}</p>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Price</Label>
                  <Input
                    value={form[priceKey as keyof typeof form]}
                    onChange={(e) => setForm({ ...form, [priceKey]: e.target.value })}
                    placeholder="£20/month"
                    className="h-9 text-sm"
                  />
                </div>
                <div className="col-span-2 space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Description</Label>
                  <Input
                    value={form[descKey as keyof typeof form]}
                    onChange={(e) => setForm({ ...form, [descKey]: e.target.value })}
                    placeholder="Short description of this plan"
                    className="h-9 text-sm"
                  />
                </div>
              </div>
              <Separator className="mt-3" />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-zinc-200/60 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Payment Link</CardTitle>
          <CardDescription>This PayPal link is used on all purchase CTAs across the app.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 p-3 bg-zinc-50 rounded-xl border border-zinc-200/60">
            <span className="text-sm text-zinc-600 font-mono flex-1 truncate">{PAYPAL_URL}</span>
            <Button variant="outline" size="sm" asChild className="shrink-0">
              <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer" className="gap-1.5">
                <ExternalLink className="h-3.5 w-3.5" /> Open
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={updateMutation.isPending}
          className="bg-zinc-900 text-white hover:bg-zinc-800 px-8"
        >
          {updateMutation.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
}
