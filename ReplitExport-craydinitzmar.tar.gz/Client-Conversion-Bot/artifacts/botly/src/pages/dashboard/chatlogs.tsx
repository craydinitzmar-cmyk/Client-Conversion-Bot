import { useState } from "react";
import { useGetChatLogs, useGetChatSession } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Zap, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

function ChatSessionDialog({ sessionId, open, onClose }: { sessionId: string | null; open: boolean; onClose: () => void }) {
  const { data: messages, isLoading } = useGetChatSession(
    { sessionId: sessionId ?? "" },
    { query: { enabled: !!sessionId && open } }
  );

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Chat Transcript</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[400px] pr-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground">Loading...</div>
          ) : (
            <div className="space-y-3 py-2">
              {(messages ?? []).map((msg, i) => (
                <div key={i} className={cn("flex", msg.role === "user" ? "justify-end" : "justify-start")}>
                  <div className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-2 text-sm",
                    msg.role === "user"
                      ? "bg-zinc-900 text-white"
                      : "bg-zinc-100 text-zinc-900"
                  )}>
                    {msg.content}
                  </div>
                </div>
              ))}
              {(messages ?? []).length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-8">No messages found.</p>
              )}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

export default function DashboardChatLogs() {
  const [page] = useState(1);
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const { data, isLoading } = useGetChatLogs({ page, limit: 20 });

  const sessions = data?.sessions ?? [];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Chat Logs</h1>
        <p className="text-muted-foreground mt-1">Review every conversation your AI has had with visitors.</p>
      </div>

      <div className="bg-white border border-zinc-200/60 rounded-2xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-50/80">
            <TableRow>
              <TableHead>Session</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Messages</TableHead>
              <TableHead>Buying Intent</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">View</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading...</TableCell>
              </TableRow>
            ) : sessions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-48 text-center text-muted-foreground">
                  <div className="flex flex-col items-center justify-center">
                    <MessageSquare className="h-10 w-10 text-zinc-300 mb-3" />
                    No chat sessions yet.
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              sessions.map((session) => (
                <TableRow key={session.sessionId} className="group transition-colors hover:bg-zinc-50/50">
                  <TableCell>
                    <span className="font-mono text-xs text-zinc-500">{session.sessionId.slice(0, 12)}…</span>
                  </TableCell>
                  <TableCell>
                    {session.leadName ? (
                      <div>
                        <div className="font-medium text-zinc-900">{session.leadName}</div>
                        {session.leadEmail && <div className="text-xs text-muted-foreground">{session.leadEmail}</div>}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">Anonymous</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className="text-sm font-medium text-zinc-700">{session.messageCount}</span>
                  </TableCell>
                  <TableCell>
                    {session.intentDetected ? (
                      <Badge variant="outline" className="border-accent/30 text-accent bg-accent/5 gap-1">
                        <Zap className="h-3 w-3" /> Detected
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">None</span>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {format(new Date(session.createdAt), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-zinc-400 hover:text-zinc-900"
                      onClick={() => setSelectedSession(session.sessionId)}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <ChatSessionDialog
        sessionId={selectedSession}
        open={!!selectedSession}
        onClose={() => setSelectedSession(null)}
      />
    </div>
  );
}
