import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Building2, Mail, Globe, Plus, Sparkles, Send, Loader2 } from "lucide-react";

const INDUSTRIES = [
  "Beauty & Lashes", "Hair & Barbering", "Restaurants & Hospitality",
  "Business Coaching", "Ecommerce", "Health & Wellness", "Other",
];

const STATUS_STYLE: Record<string, string> = {
  new: "border-zinc-300 text-zinc-600",
  contacted: "border-indigo-300 text-indigo-700 bg-indigo-50",
  converted: "border-green-300 text-green-700 bg-green-50",
  declined: "border-red-300 text-red-600 bg-red-50",
};

interface Prospect {
  id: number;
  businessName: string;
  industry: string;
  contactName: string | null;
  email: string | null;
  website: string | null;
  notes: string | null;
  status: string;
  outreachSentAt: string | null;
  createdAt: string;
}

interface NewProspect {
  businessName: string;
  industry: string;
  contactName: string;
  email: string;
  website: string;
  notes: string;
}

const BLANK: NewProspect = { businessName: "", industry: "", contactName: "", email: "", website: "", notes: "" };

export default function DashboardProspects() {
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState<NewProspect>(BLANK);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [outreachId, setOutreachId] = useState<number | null>(null);
  const [outreachEmail, setOutreachEmail] = useState("");
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  const load = () => {
    fetch(`${import.meta.env.BASE_URL}api/prospects`)
      .then((r) => r.json())
      .then((d) => { setProspects(d.prospects ?? []); setLoaded(true); });
  };

  if (!loaded) { load(); }

  const save = async () => {
    if (!form.businessName || !form.industry) return;
    setSaving(true);
    try {
      await fetch(`${import.meta.env.BASE_URL}api/prospects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setForm(BLANK);
      setShowAdd(false);
      load();
      toast({ title: "Prospect added" });
    } finally {
      setSaving(false); }
  };

  const generateOutreach = async (p: Prospect) => {
    setOutreachId(p.id);
    setOutreachEmail("");
    setGenerating(true);
    try {
      const r = await fetch(`${import.meta.env.BASE_URL}api/prospects/${p.id}/generate-outreach`, {
        method: "POST",
      });
      const d = await r.json();
      setOutreachEmail(d.email ?? "");
    } catch {
      toast({ title: "Could not generate email", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const sendOutreach = async () => {
    if (!outreachId) return;
    setSending(true);
    try {
      await fetch(`${import.meta.env.BASE_URL}api/prospects/${outreachId}/send-outreach`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: outreachEmail }),
      });
      toast({ title: "Outreach sent!" });
      setOutreachId(null);
      load();
    } catch {
      toast({ title: "Failed to send", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const activeProspect = outreachId ? prospects.find((p) => p.id === outreachId) : null;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Outreach</h1>
          <p className="text-muted-foreground mt-1">Add target businesses and let the AI write personalised outreach emails.</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-zinc-900 hover:bg-zinc-700 text-white gap-2">
          <Plus className="h-4 w-4" /> Add prospect
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {(["new", "contacted", "converted", "declined"] as const).map((s) => (
          <Card key={s} className="rounded-xl border-zinc-200/60 shadow-sm">
            <CardContent className="pt-5 pb-4 px-5">
              <div className="text-xs font-semibold text-zinc-500 uppercase tracking-wide capitalize mb-1">{s}</div>
              <div className="text-2xl font-bold text-zinc-900">{prospects.filter((p) => p.status === s).length}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* List */}
      {prospects.length === 0 ? (
        <Card className="rounded-2xl border-dashed border-zinc-300">
          <CardContent className="py-16 text-center">
            <Building2 className="h-10 w-10 text-zinc-300 mx-auto mb-3" />
            <p className="text-zinc-500 font-medium">No prospects yet</p>
            <p className="text-zinc-400 text-sm mt-1 max-w-xs mx-auto">Add a target business and the AI will write a personalised cold outreach email for you in seconds.</p>
            <Button onClick={() => setShowAdd(true)} className="mt-5 bg-zinc-900 hover:bg-zinc-700 text-white gap-2">
              <Plus className="h-4 w-4" /> Add your first prospect
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {prospects.map((p) => (
            <Card key={p.id} className="rounded-2xl border-zinc-200/60 shadow-sm overflow-hidden">
              <CardHeader className="bg-zinc-50/60 border-b pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-base">{p.businessName}</CardTitle>
                    <CardDescription className="text-xs mt-0.5">{p.industry}</CardDescription>
                  </div>
                  <Badge variant="outline" className={STATUS_STYLE[p.status] ?? ""}>
                    {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-2 text-sm text-zinc-600">
                {p.contactName && <div className="flex items-center gap-2"><Building2 className="h-3.5 w-3.5 text-zinc-400" />{p.contactName}</div>}
                {p.email && <div className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-zinc-400" />{p.email}</div>}
                {p.website && <div className="flex items-center gap-2"><Globe className="h-3.5 w-3.5 text-zinc-400" /><a href={p.website} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline truncate max-w-[180px]">{p.website.replace(/^https?:\/\//, "")}</a></div>}
                {p.notes && <p className="text-xs text-zinc-400 italic truncate">{p.notes}</p>}
                <div className="pt-2">
                  {p.outreachSentAt ? (
                    <p className="text-xs text-green-600 font-medium flex items-center gap-1"><Send className="h-3 w-3" /> Outreach sent</p>
                  ) : (
                    <Button size="sm" onClick={() => generateOutreach(p)} className="w-full gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs">
                      <Sparkles className="h-3.5 w-3.5" /> Generate outreach email
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add prospect dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add prospect</DialogTitle>
            <DialogDescription>Enter the business details. The AI will write a tailored outreach email.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Business name *</label>
              <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} placeholder="Glamour Lash Studio" />
            </div>
            <div>
              <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Industry *</label>
              <select value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })}
                className="w-full border border-zinc-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">Select industry</option>
                {INDUSTRIES.map((i) => <option key={i}>{i}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Contact name</label>
                <Input value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} placeholder="Sarah" />
              </div>
              <div>
                <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Email</label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="sarah@biz.com" />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Website</label>
              <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://glamourlash.co.uk" />
            </div>
            <div>
              <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Notes</label>
              <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Seen on Instagram, no chatbot yet" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving || !form.businessName || !form.industry} className="bg-zinc-900 hover:bg-zinc-700 text-white">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Add prospect"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Outreach email dialog */}
      <Dialog open={!!outreachId} onOpenChange={(o) => !o && setOutreachId(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Outreach email — {activeProspect?.businessName}</DialogTitle>
            <DialogDescription>AI-written. Edit before sending.</DialogDescription>
          </DialogHeader>
          {generating ? (
            <div className="py-10 flex flex-col items-center gap-3 text-zinc-400">
              <Loader2 className="h-8 w-8 animate-spin" />
              <p className="text-sm">Writing personalised email…</p>
            </div>
          ) : (
            <Textarea value={outreachEmail} onChange={(e) => setOutreachEmail(e.target.value)} rows={12} className="font-mono text-sm" />
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOutreachId(null)}>Cancel</Button>
            <Button onClick={sendOutreach} disabled={sending || generating || !outreachEmail} className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2">
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="h-4 w-4" /> Send email</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
