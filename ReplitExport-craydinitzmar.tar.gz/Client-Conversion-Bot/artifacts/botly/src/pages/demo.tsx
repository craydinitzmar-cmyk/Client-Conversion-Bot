import { useState, useRef, useEffect, useMemo } from "react";
import { useSendChatMessage, useCreateLead } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, Send, User, CreditCard, Sparkles } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  intentDetected?: boolean;
  redirectToPayment?: boolean;
}

const PAYPAL_URL = "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

export default function Demo() {
  const sessionId = useMemo(() => crypto.randomUUID(), []);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "Hello! I'm the Botly demo assistant. How can I help you today? Ask me about booking a service or purchasing a product.",
    }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadCaptured, setLeadCaptured] = useState(false);
  const [leadData, setLeadData] = useState({ name: "", email: "", phone: "" });

  const sendMutation = useSendChatMessage();
  const leadMutation = useCreateLead();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    
    // Trigger lead form after 3 messages if not captured yet
    if (messages.length > 3 && !leadCaptured && !showLeadForm) {
      setShowLeadForm(true);
    }
  }, [messages, leadCaptured, showLeadForm]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || sendMutation.isPending) return;

    const userMessage: Message = { id: crypto.randomUUID(), role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");

    sendMutation.mutate(
      { data: { message: userMessage.content, sessionId } },
      {
        onSuccess: (res) => {
          const aiMessage: Message = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: res.reply,
            intentDetected: res.intentDetected,
            redirectToPayment: res.redirectToPayment,
          };
          setMessages((prev) => [...prev, aiMessage]);
        },
      }
    );
  };

  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadData.name || !leadData.email) return;

    leadMutation.mutate(
      { data: { ...leadData, sessionId } },
      {
        onSuccess: () => {
          setShowLeadForm(false);
          setLeadCaptured(true);
          setMessages((prev) => [
            ...prev,
            {
              id: crypto.randomUUID(),
              role: "assistant",
              content: `Thanks ${leadData.name}! I've saved your details. We can continue our chat.`,
            }
          ]);
        }
      }
    );
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row bg-zinc-50 min-h-0 h-[calc(100vh-4rem)]">
      {/* Sidebar explanation */}
      <div className="hidden md:flex flex-col w-1/3 border-r bg-white p-8 overflow-y-auto">
        <h2 className="text-3xl font-bold tracking-tight mb-4">Experience the Magic</h2>
        <p className="text-muted-foreground mb-8">
          This is a live demo of the Botly conversational engine. Try asking questions, showing interest in a product, or asking to book a service.
        </p>
        
        <div className="space-y-6">
          <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-100">
            <h3 className="font-semibold flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-accent" /> Try saying:
            </h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li className="italic">"What are your business hours?"</li>
              <li className="italic">"I'm interested in buying your premium package."</li>
              <li className="italic">"How much does a haircut cost?"</li>
            </ul>
          </div>
          
          <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-100">
            <h3 className="font-semibold flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-black" /> Features to look for:
            </h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li>• Natural, human-like responses</li>
              <li>• Automatic lead capture interruption</li>
              <li>• Intent detection & payment prompts</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 flex flex-col max-w-3xl mx-auto w-full h-full p-0 md:p-6">
        <div className="flex-1 bg-white md:border md:rounded-2xl shadow-sm overflow-hidden flex flex-col h-full relative">
          {/* Chat Header */}
          <div className="h-16 border-b flex items-center px-6 bg-black text-white shrink-0 z-10">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-1.5 rounded-full">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-sm leading-tight">Botly Assistant</h3>
                <p className="text-xs text-zinc-400">Always online</p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-zinc-50/50 relative">
            {messages.map((m) => (
              <div key={m.id} className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}>
                <div className={`flex items-end gap-2 max-w-[85%] ${m.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${m.role === "user" ? "bg-accent text-white" : "bg-black text-white"}`}>
                    {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </div>
                  <div className={`p-4 rounded-2xl ${m.role === "user" ? "bg-accent text-white rounded-br-none shadow-sm" : "bg-white border shadow-sm rounded-bl-none text-zinc-800"}`}>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.content}</p>
                  </div>
                </div>

                {/* Intent Payment Button */}
                {m.redirectToPayment && (
                  <div className="mt-3 ml-10">
                    <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer">
                      <Button className="bg-black text-white hover:bg-black/80 rounded-xl shadow-lg flex items-center gap-2">
                        <CreditCard className="h-4 w-4" /> Complete Purchase
                      </Button>
                    </a>
                  </div>
                )}
              </div>
            ))}
            {sendMutation.isPending && (
              <div className="flex items-start gap-2 max-w-[80%]">
                <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center shrink-0">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="p-4 rounded-2xl bg-white border shadow-sm rounded-bl-none">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-zinc-300 rounded-full animate-bounce"></span>
                    <span className="w-2 h-2 bg-zinc-300 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></span>
                    <span className="w-2 h-2 bg-zinc-300 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></span>
                  </div>
                </div>
              </div>
            )}
            
            {/* Lead Form Overlay */}
            {showLeadForm && (
              <div className="absolute inset-0 z-20 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl animate-in fade-in zoom-in duration-200">
                  <h3 className="font-bold text-lg mb-2">Let's stay in touch</h3>
                  <p className="text-sm text-muted-foreground mb-4">Enter your details so we can assist you better.</p>
                  <form onSubmit={handleLeadSubmit} className="space-y-4">
                    <div>
                      <Input placeholder="Your Name" value={leadData.name} onChange={(e) => setLeadData({...leadData, name: e.target.value})} required className="h-12" />
                    </div>
                    <div>
                      <Input type="email" placeholder="Email Address" value={leadData.email} onChange={(e) => setLeadData({...leadData, email: e.target.value})} required className="h-12" />
                    </div>
                    <div>
                      <Input type="tel" placeholder="Phone Number (Optional)" value={leadData.phone} onChange={(e) => setLeadData({...leadData, phone: e.target.value})} className="h-12" />
                    </div>
                    <Button type="submit" className="w-full h-12 bg-black hover:bg-black/90 text-white font-bold" disabled={leadMutation.isPending}>
                      {leadMutation.isPending ? "Saving..." : "Continue Chat"}
                    </Button>
                  </form>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 bg-white border-t shrink-0 z-10">
            <form onSubmit={handleSend} className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={sendMutation.isPending || showLeadForm}
                className="h-14 rounded-xl border-zinc-200 focus-visible:ring-accent bg-zinc-50"
              />
              <Button 
                type="submit" 
                size="icon"
                disabled={!input.trim() || sendMutation.isPending || showLeadForm}
                className="h-14 w-14 shrink-0 rounded-xl bg-black hover:bg-black/80 text-white"
              >
                <Send className="h-5 w-5" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}