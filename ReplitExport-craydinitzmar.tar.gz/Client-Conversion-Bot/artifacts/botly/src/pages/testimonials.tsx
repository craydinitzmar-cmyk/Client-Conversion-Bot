import { useEffect, useState } from "react";
import { Star, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const SEED: { name: string; role: string; quote: string; rating: number; initials: string }[] = [
  { name: "Sophie Clarke", role: "Lash Technician, Manchester", quote: "I was sceptical at first, but Botly booked 3 new clients in the first week alone. It handles all my enquiries while I'm with customers.", rating: 5, initials: "SC" },
  { name: "James Okafor", role: "Restaurant Owner, Birmingham", quote: "My AI rep handles 90% of customer enquiries — opening times, menu questions, reservations. My phone stopped ringing off the hook.", rating: 5, initials: "JO" },
  { name: "Maria Santos", role: "Business Coach, London", quote: "I was losing warm leads to slow replies. Now every visitor gets an instant response and my conversion rate has doubled in a month.", rating: 5, initials: "MS" },
  { name: "Priya Nair", role: "Ecommerce Store Owner, Leeds", quote: "Return queries, shipping questions, product advice — Botly handles it all. My inbox used to be overwhelming. Now it's quiet and my sales are up.", rating: 5, initials: "PN" },
  { name: "Tom Griffiths", role: "Barbershop Owner, Cardiff", quote: "Set it up on a Sunday evening, had my first AI-booked appointment by Monday morning. It just works.", rating: 5, initials: "TG" },
  { name: "Aisha Osei", role: "Nail Technician, Bristol", quote: "Clients love getting instant replies even when I'm mid-appointment. It's like having a receptionist who never takes a break.", rating: 5, initials: "AO" },
];

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5">
      {Array(5).fill(0).map((_, i) => (
        <Star key={i} className={`h-3.5 w-3.5 ${i < n ? "text-amber-400 fill-amber-400" : "text-zinc-200"}`} />
      ))}
    </div>
  );
}

interface LiveTestimonial { id: number; name: string; role: string; quote: string; rating: number }

export default function TestimonialsPage() {
  const [live, setLive] = useState<LiveTestimonial[]>([]);
  const [form, setForm] = useState({ name: "", role: "", quote: "", rating: 5 });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetch(`${import.meta.env.BASE_URL}api/testimonials`)
      .then((r) => r.ok ? r.json() : { testimonials: [] })
      .then((d) => setLive(d.testimonials ?? []))
      .catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.role || !form.quote) return;
    setSubmitting(true);
    try {
      await fetch(`${import.meta.env.BASE_URL}api/testimonials`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setSubmitted(true);
      toast({ title: "Thank you!", description: "Your review has been submitted for approval." });
    } finally {
      setSubmitting(false);
    }
  };

  const all = [...SEED, ...live.map((t) => ({ ...t, initials: t.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase() }))];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-zinc-900 text-white py-20 px-6 text-center">
        <span className="text-xs font-semibold tracking-widest uppercase text-indigo-400 mb-4 block">Customer Stories</span>
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Real businesses.<br className="hidden sm:block" /> Real results.</h1>
        <p className="text-zinc-400 text-lg max-w-lg mx-auto">See how small businesses use Botly to capture leads, book appointments, and grow revenue — automatically.</p>
        <div className="flex items-center justify-center gap-1 mt-6">
          {Array(5).fill(0).map((_, i) => <Star key={i} className="h-5 w-5 text-amber-400 fill-amber-400" />)}
          <span className="ml-2 text-zinc-300 text-sm">Rated 5/5 by our customers</span>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {all.map((t, i) => (
            <div key={i} className="break-inside-avoid bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all">
              <Stars n={t.rating} />
              <p className="text-zinc-700 mt-4 mb-5 leading-relaxed text-sm">"{t.quote}"</p>
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-indigo-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                  {t.initials}
                </div>
                <div>
                  <p className="font-semibold text-sm text-zinc-900">{t.name}</p>
                  <p className="text-xs text-zinc-500">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submit form */}
      <div className="bg-zinc-50 border-t border-zinc-200 py-16 px-6">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-zinc-900 mb-2 text-center">Share your story</h2>
          <p className="text-zinc-500 text-sm text-center mb-8">Using Botly? We'd love to feature your experience.</p>
          {submitted ? (
            <div className="text-center py-10">
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Send className="h-5 w-5 text-green-600" />
              </div>
              <p className="font-semibold text-zinc-900">Thanks for sharing!</p>
              <p className="text-zinc-500 text-sm mt-1">Your review will appear here once approved.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Your name</label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Sarah Jones" required />
                </div>
                <div>
                  <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Your role</label>
                  <Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="Salon Owner, London" required />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-1 block">Your review</label>
                <Textarea value={form.quote} onChange={(e) => setForm({ ...form, quote: e.target.value })} placeholder="How has Botly helped your business?" rows={4} required />
              </div>
              <div>
                <label className="text-xs font-semibold text-zinc-600 uppercase tracking-wide mb-2 block">Rating</label>
                <div className="flex gap-1">
                  {[1,2,3,4,5].map((n) => (
                    <button key={n} type="button" onClick={() => setForm({ ...form, rating: n })}>
                      <Star className={`h-6 w-6 transition-colors ${n <= form.rating ? "text-amber-400 fill-amber-400" : "text-zinc-300"}`} />
                    </button>
                  ))}
                </div>
              </div>
              <Button type="submit" disabled={submitting} className="w-full bg-zinc-900 hover:bg-zinc-700 text-white">
                {submitting ? "Submitting…" : "Submit review"}
              </Button>
            </form>
          )}
        </div>
      </div>

      {/* CTA */}
      <div className="py-16 px-6 text-center bg-indigo-600">
        <p className="text-white font-bold text-2xl mb-2">Join hundreds of small businesses</p>
        <p className="text-indigo-200 mb-6">Start capturing leads and bookings automatically.</p>
        <a href="/pricing" className="inline-block bg-white text-indigo-700 font-semibold px-8 py-3.5 rounded-xl text-sm hover:bg-indigo-50 transition-colors">
          Start free trial
        </a>
      </div>
    </div>
  );
}
