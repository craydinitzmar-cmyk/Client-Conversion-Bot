import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { useTrackReferral } from "@/hooks/use-referral";

import MarketingLayout from "@/components/layout/MarketingLayout";
import DashboardLayout from "@/components/layout/DashboardLayout";

import Home from "@/pages/index";
import Pricing from "@/pages/pricing";
import Demo from "@/pages/demo";
import DashboardOverview from "@/pages/dashboard/index";
import DashboardLeads from "@/pages/dashboard/leads";
import DashboardChatLogs from "@/pages/dashboard/chatlogs";
import DashboardFaq from "@/pages/dashboard/faq";
import DashboardSettings from "@/pages/dashboard/settings";
import DashboardEmbed from "@/pages/dashboard/embed";
import DashboardReferrals from "@/pages/dashboard/referrals";
import DashboardEmailQueue from "@/pages/dashboard/email-queue";
import DashboardHandoffs from "@/pages/dashboard/handoffs";
import DashboardBookings from "@/pages/dashboard/bookings";
import DashboardProspects from "@/pages/dashboard/prospects";
import FreeTrial from "@/pages/free-trial";
import Blog from "@/pages/blog";
import Testimonials from "@/pages/testimonials";
import ReferPage from "@/pages/refer";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

function Router() {
  useTrackReferral();
  return (
    <Switch>
      <Route path="/">
        <MarketingLayout><Home /></MarketingLayout>
      </Route>
      <Route path="/pricing">
        <MarketingLayout><Pricing /></MarketingLayout>
      </Route>
      <Route path="/demo">
        <MarketingLayout><Demo /></MarketingLayout>
      </Route>
      <Route path="/dashboard">
        <DashboardLayout><DashboardOverview /></DashboardLayout>
      </Route>
      <Route path="/dashboard/leads">
        <DashboardLayout><DashboardLeads /></DashboardLayout>
      </Route>
      <Route path="/dashboard/chatlogs">
        <DashboardLayout><DashboardChatLogs /></DashboardLayout>
      </Route>
      <Route path="/dashboard/faq">
        <DashboardLayout><DashboardFaq /></DashboardLayout>
      </Route>
      <Route path="/dashboard/settings">
        <DashboardLayout><DashboardSettings /></DashboardLayout>
      </Route>
      <Route path="/dashboard/embed">
        <DashboardLayout><DashboardEmbed /></DashboardLayout>
      </Route>
      <Route path="/dashboard/referrals">
        <DashboardLayout><DashboardReferrals /></DashboardLayout>
      </Route>
      <Route path="/dashboard/emails">
        <DashboardLayout><DashboardEmailQueue /></DashboardLayout>
      </Route>
      <Route path="/dashboard/handoffs">
        <DashboardLayout><DashboardHandoffs /></DashboardLayout>
      </Route>
      <Route path="/dashboard/bookings">
        <DashboardLayout><DashboardBookings /></DashboardLayout>
      </Route>
      <Route path="/dashboard/prospects">
        <DashboardLayout><DashboardProspects /></DashboardLayout>
      </Route>
      <Route path="/free-trial">
        <MarketingLayout><FreeTrial /></MarketingLayout>
      </Route>
      <Route path="/blog/:slug">
        {(params) => <MarketingLayout><Blog slug={params.slug} /></MarketingLayout>}
      </Route>
      <Route path="/blog">
        <MarketingLayout><Blog /></MarketingLayout>
      </Route>
      <Route path="/testimonials">
        <MarketingLayout><Testimonials /></MarketingLayout>
      </Route>
      <Route path="/refer">
        <MarketingLayout><ReferPage /></MarketingLayout>
      </Route>
      <Route>
        <MarketingLayout><NotFound /></MarketingLayout>
      </Route>
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}