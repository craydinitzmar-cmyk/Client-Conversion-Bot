import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, Users, MessageSquare, Settings, HelpCircle, Bot, Code2, Gift, Mail, PhoneForwarded, CalendarCheck, Target } from "lucide-react";

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/leads", label: "Leads", icon: Users },
    { href: "/dashboard/chatlogs", label: "Chat Logs", icon: MessageSquare },
    { href: "/dashboard/faq", label: "FAQs", icon: HelpCircle },
    { href: "/dashboard/embed", label: "Embed Widget", icon: Code2 },
    { href: "/dashboard/referrals", label: "Referrals", icon: Gift },
    { href: "/dashboard/bookings", label: "Bookings", icon: CalendarCheck },
    { href: "/dashboard/prospects", label: "Outreach", icon: Target },
    { href: "/dashboard/handoffs", label: "Handoffs", icon: PhoneForwarded },
    { href: "/dashboard/emails", label: "Email Sequences", icon: Mail },
    { href: "/dashboard/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="flex min-h-[100dvh] w-full flex-col bg-muted/30 md:flex-row">
      <aside className="fixed inset-y-0 left-0 z-10 hidden w-64 flex-col border-r bg-background md:flex">
        <div className="flex h-16 items-center border-b px-6">
          <Link href="/" className="flex items-center gap-2 font-bold tracking-tight text-lg">
            <div className="bg-primary text-primary-foreground p-1 rounded-md">
              <Bot className="h-4 w-4" />
            </div>
            Botly Admin
          </Link>
        </div>
        <nav className="flex-1 overflow-auto py-4 px-3">
          <ul className="grid gap-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-all ${
                      isActive
                        ? "bg-accent/10 text-accent"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    }`}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>
      <main className="flex flex-1 flex-col md:pl-64">
        {/* Mobile Header */}
        <header className="flex h-16 items-center border-b bg-background px-4 md:hidden">
          <Link href="/dashboard" className="flex items-center gap-2 font-bold">
            <Bot className="h-5 w-5" />
            Botly
          </Link>
        </header>
        <div className="flex-1 p-6 lg:p-8 max-w-6xl mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
}