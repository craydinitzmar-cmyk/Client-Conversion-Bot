import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Bot } from "lucide-react";
import ExitIntentPopup from "@/components/ExitIntentPopup";

export default function MarketingLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 max-w-screen-2xl items-center justify-between mx-auto px-4">
          <Link href="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
            <div className="bg-primary text-primary-foreground p-1.5 rounded-md">
              <Bot className="h-5 w-5" />
            </div>
            <span className="font-bold tracking-tight text-lg">Botly</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <Link href="/" className={`transition-colors hover:text-foreground/80 ${location === "/" ? "text-foreground" : "text-foreground/60"}`}>Home</Link>
            <Link href="/pricing" className={`transition-colors hover:text-foreground/80 ${location === "/pricing" ? "text-foreground" : "text-foreground/60"}`}>Pricing</Link>
            <Link href="/demo" className={`transition-colors hover:text-foreground/80 ${location === "/demo" ? "text-foreground" : "text-foreground/60"}`}>Demo</Link>
            <Link href="/blog" className={`transition-colors hover:text-foreground/80 ${location.startsWith("/blog") ? "text-foreground" : "text-foreground/60"}`}>Blog</Link>
            <Link href="/testimonials" className={`transition-colors hover:text-foreground/80 ${location === "/testimonials" ? "text-foreground" : "text-foreground/60"}`}>Reviews</Link>
            <Link href="/dashboard" className="transition-colors hover:text-foreground/80 text-foreground/60">Dashboard</Link>
            <Link href="/refer" className={`transition-colors hover:text-foreground/80 font-semibold text-indigo-600 ${location === "/refer" ? "text-indigo-700" : ""}`}>Refer &amp; Earn</Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/free-trial">
              <Button variant="default" className="font-semibold tracking-wide">
                Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col">
        {children}
      </main>
      <ExitIntentPopup />
      <footer className="border-t py-12 md:py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Bot className="h-6 w-6" />
            <span className="font-bold text-xl">Botly</span>
          </div>
          <p className="text-sm text-muted-foreground mb-8">AI Customer Support That Sells For You 24/7</p>
          <div className="flex justify-center gap-6 text-sm text-muted-foreground">
            <Link href="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link href="/pricing" className="hover:text-foreground transition-colors">Pricing</Link>
            <Link href="/demo" className="hover:text-foreground transition-colors">Demo</Link>
            <Link href="/blog" className="hover:text-foreground transition-colors">Blog</Link>
            <Link href="/testimonials" className="hover:text-foreground transition-colors">Reviews</Link>
            <Link href="/free-trial" className="hover:text-foreground transition-colors">Free Trial</Link>
            <Link href="/refer" className="hover:text-foreground transition-colors font-medium text-indigo-500">Refer &amp; Earn</Link>
          </div>
          <div className="mt-12 text-xs text-muted-foreground/50">
            &copy; {new Date().getFullYear()} Botly. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}