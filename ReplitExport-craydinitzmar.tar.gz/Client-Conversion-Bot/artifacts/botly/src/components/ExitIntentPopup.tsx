import { useEffect, useState } from "react";
import { useCreateLead } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Zap } from "lucide-react";
import { convertReferral } from "@/hooks/use-referral";

const PAYPAL_URL = "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

export default function ExitIntentPopup() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const createLead = useCreateLead();

  useEffect(() => {
    if (dismissed) return;
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !dismissed && !visible) {
        setVisible(true);
      }
    };
    document.addEventListener("mouseleave", handleMouseLeave);
    return () => document.removeEventListener("mouseleave", handleMouseLeave);
  }, [dismissed, visible]);

  const handleDismiss = () => {
    setVisible(false);
    setDismissed(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;
    createLead.mutate(
      { data: { name, email, sessionId: "exit-intent-" + Date.now() } },
      { onSuccess: () => { setSubmitted(true); convertReferral(email, name); } }
    );
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden relative animate-in zoom-in-95 duration-200">
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-700 transition-colors z-10"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="bg-zinc-950 px-8 pt-8 pb-6 text-white text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-white/10 mb-4">
            <Zap className="h-7 w-7 text-yellow-400" />
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight mb-2">
            Wait — before you go
          </h2>
          <p className="text-zinc-400 text-sm leading-relaxed">
            Start your <span className="text-white font-semibold">7-day free trial</span> today. No payment needed upfront. Cancel anytime.
          </p>
        </div>

        <div className="px-8 py-6">
          {submitted ? (
            <div className="text-center py-4">
              <div className="text-3xl mb-3">Done!</div>
              <p className="font-semibold text-zinc-900 mb-1">You're on the list.</p>
              <p className="text-sm text-muted-foreground mb-6">
                We'll be in touch shortly to get your AI set up. Ready to start now?
              </p>
              <a href={PAYPAL_URL} target="_blank" rel="noopener noreferrer">
                <Button className="w-full h-12 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl">
                  Activate My Plan Now
                </Button>
              </a>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <Input
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12 rounded-xl"
                required
              />
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12 rounded-xl"
                required
              />
              <Button
                type="submit"
                disabled={createLead.isPending}
                className="w-full h-12 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl text-base"
              >
                {createLead.isPending ? "Saving..." : "Claim Free Trial"}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                No credit card required. Takes 30 seconds.
              </p>
            </form>
          )}

          <button
            onClick={handleDismiss}
            className="w-full text-center text-xs text-muted-foreground hover:text-zinc-700 mt-3 transition-colors"
          >
            No thanks, I don't want more leads
          </button>
        </div>
      </div>
    </div>
  );
}
