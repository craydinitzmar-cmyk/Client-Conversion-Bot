import nodemailer from "nodemailer";

let transporter: nodemailer.Transporter | null = null;

function getTransporter(): nodemailer.Transporter | null {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return transporter;
}

export interface LeadNotificationData {
  name: string;
  email: string;
  phone?: string | null;
  sessionId: string;
  createdAt: string;
}

export interface HandoffAlertData {
  sessionId: string;
  triggerMessage: string;
  flagReason: string;
  transcript: Array<{ role: string; content: string }>;
}

export async function sendHandoffAlert(data: HandoffAlertData): Promise<void> {
  const transport = getTransporter();
  if (!transport) return;

  const to = process.env.NOTIFICATION_EMAIL ?? process.env.SMTP_USER;
  if (!to) return;

  const dashboardUrl = process.env.REPLIT_DOMAINS
    ? `https://${process.env.REPLIT_DOMAINS.split(",")[0].trim()}/dashboard/handoffs`
    : "your Botly dashboard";

  const transcriptHtml = data.transcript
    .map(
      (m) =>
        `<div style="margin-bottom:10px;display:flex;justify-content:${m.role === "user" ? "flex-end" : "flex-start"}">
          <div style="max-width:80%;padding:10px 14px;border-radius:12px;font-size:13px;line-height:1.6;
            background:${m.role === "user" ? "#18181b" : "#f4f4f5"};
            color:${m.role === "user" ? "#fff" : "#18181b"};">
            ${m.content.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
          </div>
        </div>`
    )
    .join("");

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f4f4f5; margin: 0; padding: 32px 16px; }
    .card { background: #fff; border-radius: 16px; max-width: 520px; margin: 0 auto; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
    .header { background: #b45309; padding: 28px 32px; }
    .header h1 { color: #fff; font-size: 20px; font-weight: 700; margin: 0; }
    .header p { color: #fde68a; font-size: 13px; margin: 6px 0 0; }
    .body { padding: 28px 32px; }
    .label { font-size: 11px; font-weight: 600; color: #71717a; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; }
    .value { font-size: 14px; color: #18181b; font-weight: 500; margin-bottom: 16px; }
    .trigger { background: #fef3c7; border: 1px solid #fde68a; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; font-size: 14px; color: #92400e; font-style: italic; }
    .transcript { background: #f9f9f9; border-radius: 12px; padding: 16px; margin: 16px 0; max-height: 400px; overflow-y: auto; }
    .btn { display: inline-block; background: #18181b; color: #fff; text-decoration: none; font-size: 14px; font-weight: 600; padding: 12px 24px; border-radius: 10px; }
    .footer { padding: 16px 32px; border-top: 1px solid #f0f0f0; text-align: center; }
    .footer p { font-size: 12px; color: #a1a1aa; margin: 0; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <h1>Handoff Required</h1>
      <p>A customer needs to speak to a real person — action needed</p>
    </div>
    <div class="body">
      <div class="label">Trigger phrase detected</div>
      <div class="trigger">"${data.triggerMessage.replace(/</g, "&lt;").replace(/>/g, "&gt;")}"</div>
      <div class="label">Matched rule</div>
      <div class="value">${data.flagReason}</div>
      <div class="label">Session ID</div>
      <div class="value" style="font-family:monospace;font-size:12px;color:#71717a;">${data.sessionId}</div>
      <div class="label">Conversation transcript</div>
      <div class="transcript">${transcriptHtml}</div>
      <a href="${dashboardUrl}" class="btn">View &amp; Resolve in Dashboard</a>
    </div>
    <div class="footer">
      <p>Sent by Botly &mdash; AI Customer Support</p>
    </div>
  </div>
</body>
</html>`.trim();

  await transport.sendMail({
    from: `"Botly Alerts" <${process.env.SMTP_USER}>`,
    to,
    subject: `Action needed: customer requesting handoff — "${data.triggerMessage.slice(0, 60)}"`,
    html,
    text: `A customer needs a human.\n\nTrigger: "${data.triggerMessage}"\nRule: ${data.flagReason}\nSession: ${data.sessionId}\n\nView in dashboard: ${dashboardUrl}`,
  });
}

export interface BookingNotificationData {
  sessionId: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  service: string | null;
  preferredDate: string | null;
  preferredTime: string | null;
}

export async function sendBookingNotification(b: BookingNotificationData): Promise<void> {
  const transport = getTransporter();
  if (!transport) return;
  const to = process.env.NOTIFICATION_EMAIL ?? process.env.SMTP_USER;
  if (!to) return;

  const dashboardUrl = process.env.REPLIT_DOMAINS
    ? `https://${process.env.REPLIT_DOMAINS.split(",")[0].trim()}/dashboard/bookings`
    : "your Botly dashboard";

  const row = (label: string, val: string | null) =>
    val ? `<div class="label">${label}</div><div class="value">${val}</div>` : "";

  const html = `
<!DOCTYPE html><html><head><meta charset="utf-8" />
<style>
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f4f4f5;margin:0;padding:32px 16px;}
  .card{background:#fff;border-radius:16px;max-width:480px;margin:0 auto;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);}
  .header{background:#18181b;padding:28px 32px;}
  .header h1{color:#fff;font-size:20px;font-weight:700;margin:0;}
  .header p{color:#a1a1aa;font-size:13px;margin:6px 0 0;}
  .body{padding:28px 32px;}
  .badge{display:inline-block;background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe;border-radius:20px;font-size:12px;font-weight:600;padding:3px 10px;margin-bottom:20px;}
  .label{font-size:11px;font-weight:600;color:#71717a;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:4px;}
  .value{font-size:15px;color:#18181b;font-weight:500;margin-bottom:16px;}
  .btn{display:inline-block;background:#18181b;color:#fff;text-decoration:none;font-size:14px;font-weight:600;padding:12px 24px;border-radius:10px;}
  .footer{padding:16px 32px;border-top:1px solid #f0f0f0;text-align:center;}
  .footer p{font-size:12px;color:#a1a1aa;margin:0;}
</style></head><body>
<div class="card">
  <div class="header"><h1>New Booking Request</h1><p>A customer booked an appointment via your AI chat widget</p></div>
  <div class="body">
    <span class="badge">New Booking</span>
    ${row("Name", b.name)}
    ${row("Email", b.email)}
    ${row("Phone", b.phone)}
    ${row("Service", b.service)}
    ${row("Preferred Date", b.preferredDate)}
    ${row("Preferred Time", b.preferredTime)}
    <a href="${dashboardUrl}" class="btn">View in Dashboard</a>
  </div>
  <div class="footer"><p>Sent by Botly &mdash; AI Customer Support</p></div>
</div></body></html>`.trim();

  await transport.sendMail({
    from: `"Botly Bookings" <${process.env.SMTP_USER}>`,
    to,
    subject: `New booking: ${b.name ?? "Unknown"} — ${b.service ?? "appointment"}`,
    html,
    text: `New booking!\n\nName: ${b.name ?? "—"}\nEmail: ${b.email ?? "—"}\nPhone: ${b.phone ?? "—"}\nService: ${b.service ?? "—"}\nDate: ${b.preferredDate ?? "—"}\nTime: ${b.preferredTime ?? "—"}\n\nView: ${dashboardUrl}`,
  });
}

export async function sendRawEmail({ to, subject, text }: { to: string; subject: string; text: string }): Promise<void> {
  const transport = getTransporter();
  if (!transport) return;
  await transport.sendMail({
    from: `"Botly" <${process.env.SMTP_USER}>`,
    to,
    subject,
    text,
  });
}

export async function sendLeadNotification(lead: LeadNotificationData): Promise<void> {
  const transport = getTransporter();
  if (!transport) return;

  const to = process.env.NOTIFICATION_EMAIL ?? process.env.SMTP_USER;
  if (!to) return;

  const dashboardUrl = process.env.REPLIT_DOMAINS
    ? `https://${process.env.REPLIT_DOMAINS.split(",")[0].trim()}/dashboard/leads`
    : "your Botly dashboard";

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f4f4f5; margin: 0; padding: 32px 16px; }
    .card { background: #fff; border-radius: 16px; max-width: 480px; margin: 0 auto; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
    .header { background: #18181b; padding: 28px 32px; }
    .header h1 { color: #fff; font-size: 20px; font-weight: 700; margin: 0; }
    .header p { color: #a1a1aa; font-size: 13px; margin: 6px 0 0; }
    .body { padding: 28px 32px; }
    .label { font-size: 11px; font-weight: 600; color: #71717a; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; }
    .value { font-size: 15px; color: #18181b; font-weight: 500; margin-bottom: 18px; }
    .badge { display: inline-block; background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; border-radius: 20px; font-size: 12px; font-weight: 600; padding: 3px 10px; margin-bottom: 24px; }
    .btn { display: inline-block; background: #18181b; color: #fff; text-decoration: none; font-size: 14px; font-weight: 600; padding: 12px 24px; border-radius: 10px; }
    .footer { padding: 16px 32px; border-top: 1px solid #f0f0f0; text-align: center; }
    .footer p { font-size: 12px; color: #a1a1aa; margin: 0; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <h1>New Lead Captured</h1>
      <p>Your Botly AI assistant captured a new contact</p>
    </div>
    <div class="body">
      <span class="badge">New Lead</span>
      <div class="label">Name</div>
      <div class="value">${lead.name}</div>
      <div class="label">Email</div>
      <div class="value">${lead.email}</div>
      ${lead.phone ? `<div class="label">Phone</div><div class="value">${lead.phone}</div>` : ""}
      <div class="label">Session ID</div>
      <div class="value" style="font-family: monospace; font-size: 13px; color: #71717a;">${lead.sessionId}</div>
      <div class="label">Captured At</div>
      <div class="value">${new Date(lead.createdAt).toLocaleString("en-GB", { dateStyle: "full", timeStyle: "short" })}</div>
      <a href="${dashboardUrl}" class="btn">View in Dashboard</a>
    </div>
    <div class="footer">
      <p>Sent by Botly &mdash; AI Customer Support</p>
    </div>
  </div>
</body>
</html>
  `.trim();

  await transport.sendMail({
    from: `"Botly Notifications" <${process.env.SMTP_USER}>`,
    to,
    subject: `New lead: ${lead.name} — ${lead.email}`,
    html,
    text: `New lead captured!\n\nName: ${lead.name}\nEmail: ${lead.email}${lead.phone ? `\nPhone: ${lead.phone}` : ""}\nSession: ${lead.sessionId}\nCaptured: ${lead.createdAt}\n\nView in dashboard: ${dashboardUrl}`,
  });
}
