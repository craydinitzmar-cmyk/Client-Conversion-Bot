import { db, emailQueueTable } from "@workspace/db";

const PAYPAL_URL =
  "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

function appUrl(): string {
  const domain = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
  return domain ? `https://${domain}` : "https://botly.replit.app";
}

function baseHtml(previewText: string, bodyContent: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="x-apple-disable-message-reformatting" />
  <title>Botly</title>
  <!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript><![endif]-->
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; padding: 0; background: #f4f4f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; -webkit-text-size-adjust: 100%; }
    .wrapper { padding: 40px 16px; }
    .card { background: #ffffff; border-radius: 20px; max-width: 520px; margin: 0 auto; overflow: hidden; box-shadow: 0 4px 32px rgba(0,0,0,0.10); }
    .header { background: #09090b; padding: 32px 40px 28px; }
    .logo { display: flex; align-items: center; gap: 10px; margin-bottom: 0; }
    .logo-icon { width: 36px; height: 36px; background: #18181b; border: 1.5px solid #3f3f46; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; }
    .logo-text { color: #ffffff; font-size: 18px; font-weight: 700; letter-spacing: -0.3px; }
    .body { padding: 36px 40px; }
    .body h1 { font-size: 24px; font-weight: 800; color: #09090b; margin: 0 0 12px; letter-spacing: -0.5px; line-height: 1.25; }
    .body p { font-size: 15px; color: #52525b; line-height: 1.7; margin: 0 0 16px; }
    .body strong { color: #09090b; }
    .highlight-box { background: #fafafa; border: 1px solid #e4e4e7; border-radius: 12px; padding: 20px 24px; margin: 24px 0; }
    .highlight-box p { margin: 0; color: #3f3f46; font-size: 14px; }
    .stat-row { display: flex; gap: 0; border: 1px solid #e4e4e7; border-radius: 12px; overflow: hidden; margin: 24px 0; }
    .stat { flex: 1; padding: 18px 16px; text-align: center; border-right: 1px solid #e4e4e7; }
    .stat:last-child { border-right: none; }
    .stat-num { font-size: 22px; font-weight: 800; color: #4f46e5; display: block; }
    .stat-label { font-size: 11px; color: #71717a; margin-top: 2px; display: block; }
    .quote-box { border-left: 3px solid #4f46e5; padding: 16px 20px; background: #f5f3ff; border-radius: 0 12px 12px 0; margin: 20px 0; }
    .quote-box p { margin: 0 0 8px; font-style: italic; font-size: 14px; color: #3f3f46; }
    .quote-author { font-size: 12px; font-weight: 600; color: #6d28d9; }
    .cta-wrap { text-align: center; margin: 32px 0 8px; }
    .cta { display: inline-block; background: #4f46e5; color: #ffffff !important; text-decoration: none; font-size: 15px; font-weight: 700; padding: 15px 36px; border-radius: 100px; letter-spacing: 0.1px; }
    .cta-note { text-align: center; font-size: 12px; color: #a1a1aa; margin-top: 10px; }
    .steps { list-style: none; margin: 20px 0; padding: 0; }
    .steps li { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 14px; font-size: 14px; color: #52525b; }
    .step-num { width: 26px; height: 26px; background: #09090b; color: #fff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; flex-shrink: 0; margin-top: 1px; }
    .divider { border: none; border-top: 1px solid #f0f0f0; margin: 28px 0; }
    .footer { background: #fafafa; border-top: 1px solid #f0f0f0; padding: 20px 40px; text-align: center; }
    .footer p { font-size: 12px; color: #a1a1aa; margin: 0; line-height: 1.6; }
    .footer a { color: #a1a1aa; }
    .urgency-bar { background: #fef3c7; border-bottom: 1px solid #fde68a; padding: 12px 24px; text-align: center; }
    .urgency-bar p { margin: 0; font-size: 13px; font-weight: 600; color: #92400e; }
  </style>
</head>
<body>
  <span style="display:none;max-height:0;overflow:hidden;">${previewText}</span>
  <div class="wrapper">
    <div class="card">
      <div class="header">
        <div class="logo">
          <span class="logo-text">Botly</span>
        </div>
      </div>
      ${bodyContent}
      <div class="footer">
        <p>Botly &mdash; AI Customer Support for Small Businesses<br />
        <a href="${appUrl()}">Visit Botly</a> &nbsp;&middot;&nbsp; You're receiving this because you signed up for a free trial.</p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

interface EmailTemplate {
  subject: string;
  html: string;
}

export function buildEmail1(name: string): EmailTemplate {
  const firstName = name.split(" ")[0];
  const subject = `Welcome to Botly, ${firstName} — your AI is getting ready`;
  const html = baseHtml(
    `Your Botly AI assistant is being set up and will be live within 24 hours.`,
    `
    <div class="body">
      <h1>You're in, ${firstName}.</h1>
      <p>Thank you for signing up to Botly. Your AI customer support assistant is being set up and will be ready to go live on your website within <strong>24 hours</strong>.</p>

      <div class="highlight-box">
        <p>Here's what happens next:</p>
      </div>
      <ul class="steps">
        <li><span class="step-num">1</span><span>We train your AI with your business details and FAQ knowledge base</span></li>
        <li><span class="step-num">2</span><span>You receive a single line of code to paste on your website</span></li>
        <li><span class="step-num">3</span><span>Your AI goes live and starts capturing leads immediately</span></li>
      </ul>

      <hr class="divider" />

      <p>Want to get set up even faster? <strong>Activate your plan now</strong> and jump to the front of the queue. Starter plans start at just £20/month.</p>

      <div class="cta-wrap">
        <a href="${PAYPAL_URL}" class="cta">Activate My Plan via PayPal</a>
      </div>
      <p class="cta-note">Secure payment via PayPal &nbsp;&middot;&nbsp; Cancel anytime</p>

      <hr class="divider" />
      <p style="font-size:13px;color:#71717a;">Questions? Just reply to this email and we'll get back to you.</p>
    </div>`
  );
  return { subject, html };
}

export function buildEmail2(name: string): EmailTemplate {
  const firstName = name.split(" ")[0];
  const subject = `${firstName}, see what other businesses are achieving with Botly`;
  const html = baseHtml(
    `500+ businesses are using Botly to capture leads and close sales 24/7.`,
    `
    <div class="body">
      <h1>You're in good company.</h1>
      <p>Over <strong>500 small businesses</strong> — salons, coaches, restaurants, ecommerce stores — are using Botly right now. Here's what they're seeing:</p>

      <div class="stat-row">
        <div class="stat"><span class="stat-num">50K+</span><span class="stat-label">Chats handled</span></div>
        <div class="stat"><span class="stat-num">12K+</span><span class="stat-label">Leads captured</span></div>
        <div class="stat"><span class="stat-num">2s</span><span class="stat-label">Avg response time</span></div>
      </div>

      <div class="quote-box">
        <p>"I was losing warm leads to slow replies. Now every visitor gets an instant response and my conversion rate has doubled."</p>
        <span class="quote-author">Maria Santos &mdash; Business Coach, London</span>
      </div>

      <div class="quote-box">
        <p>"Botly booked 3 new lash clients in the first week. It pays for itself ten times over."</p>
        <span class="quote-author">Sophie Clarke &mdash; Lash Technician, Manchester</span>
      </div>

      <p>Your AI is ready to do the same for your business — answering questions, capturing leads, and pushing visitors toward booking or buying, <strong>24 hours a day, 7 days a week</strong>.</p>

      <div class="cta-wrap">
        <a href="${PAYPAL_URL}" class="cta">Start My Plan — From £20/mo</a>
      </div>
      <p class="cta-note">30-day money-back guarantee &nbsp;&middot;&nbsp; No contracts</p>
    </div>`
  );
  return { subject, html };
}

export function buildEmail3(name: string): EmailTemplate {
  const firstName = name.split(" ")[0];
  const subject = `${firstName}, your free trial ends soon — don't lose your spot`;
  const html = baseHtml(
    `Your Botly free trial period is almost up. Activate your plan to keep your AI running.`,
    `
    <div class="urgency-bar">
      <p>Your 7-day free trial expires soon</p>
    </div>
    <div class="body">
      <h1>Don't go back to missing leads.</h1>
      <p>Hi ${firstName}, your Botly free trial is almost over. Once it ends, your AI stops answering customer questions — and every missed message is a missed sale.</p>

      <div class="highlight-box">
        <p>While your AI has been running, businesses like yours have been:</p>
        <ul style="margin:12px 0 0;padding-left:20px;font-size:14px;color:#52525b;line-height:1.8;">
          <li>Capturing leads overnight while they sleep</li>
          <li>Answering pricing questions instantly — without picking up the phone</li>
          <li>Pushing warm visitors directly to their booking or payment page</li>
        </ul>
      </div>

      <p>Activate your plan today and keep that momentum going. <strong>Starter plans are just £20/month</strong> — less than the value of a single new customer.</p>

      <div class="cta-wrap">
        <a href="${PAYPAL_URL}" class="cta">Activate Now &mdash; Keep My AI Running</a>
      </div>
      <p class="cta-note">Protected by our 30-day money-back guarantee</p>

      <hr class="divider" />
      <p style="font-size:13px;color:#71717a;">If you have any questions before deciding, just reply to this email. We're happy to help.</p>
    </div>`
  );
  return { subject, html };
}

export async function scheduleEmailSequence(params: {
  leadId: number;
  toEmail: string;
  toName: string;
}): Promise<void> {
  const now = new Date();

  const email1 = buildEmail1(params.toName);
  const email2 = buildEmail2(params.toName);
  const email3 = buildEmail3(params.toName);

  const day1 = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const day2 = new Date(now.getTime() + 48 * 60 * 60 * 1000);

  await db.insert(emailQueueTable).values([
    {
      leadId: params.leadId,
      toEmail: params.toEmail,
      toName: params.toName,
      subject: email1.subject,
      bodyHtml: email1.html,
      sequenceStep: 1,
      scheduledAt: now,
    },
    {
      leadId: params.leadId,
      toEmail: params.toEmail,
      toName: params.toName,
      subject: email2.subject,
      bodyHtml: email2.html,
      sequenceStep: 2,
      scheduledAt: day1,
    },
    {
      leadId: params.leadId,
      toEmail: params.toEmail,
      toName: params.toName,
      subject: email3.subject,
      bodyHtml: email3.html,
      sequenceStep: 3,
      scheduledAt: day2,
    },
  ]);
}
