import { Router, type IRouter } from "express";
import { eq, desc, sql, count } from "drizzle-orm";
import { db, chatMessagesTable, leadsTable, handoffsTable, bookingsTable } from "@workspace/db";
import {
  SendChatMessageBody,
  SendChatMessageResponse,
  GetChatLogsQueryParams,
  GetChatLogsResponse,
  GetChatSessionParams,
  GetChatSessionResponse,
} from "@workspace/api-zod";
import { sendHandoffAlert, sendBookingNotification } from "../email";

const PAYPAL_URL =
  "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

const BUYING_INTENT_KEYWORDS = [
  "price",
  "pricing",
  "cost",
  "how much",
  "buy",
  "purchase",
  "pay",
  "payment",
  "setup",
  "get started",
  "sign up",
  "subscribe",
  "plan",
  "start",
  "starter",
  "business",
  "premium",
  "£",
  "month",
];

function detectBuyingIntent(message: string): boolean {
  const lower = message.toLowerCase();
  return BUYING_INTENT_KEYWORDS.some((kw) => lower.includes(kw));
}

const HANDOFF_KEYWORDS = [
  "speak to someone", "speak to a person", "speak to a human",
  "talk to someone", "talk to a person", "talk to a human",
  "real person", "actual person", "human agent", "live agent",
  "live support", "live chat", "human support",
  "manager", "supervisor", "speak to a manager",
  "complaint", "make a complaint",
  "refund", "cancel my", "cancellation",
  "urgent", "emergency",
  "that's wrong", "thats wrong", "that is wrong",
  "not helpful", "not what i asked", "not what i wanted",
  "i'm not happy", "im not happy", "not happy",
  "frustrated", "this is terrible", "useless",
  "angry", "this is ridiculous",
];

function detectHandoffRequest(message: string): string | null {
  const lower = message.toLowerCase();
  for (const kw of HANDOFF_KEYWORDS) {
    if (lower.includes(kw)) return kw;
  }
  return null;
}

const BOOKING_KEYWORDS = [
  "book", "booking", "appointment", "schedule", "availability", "available",
  "reserve", "reservation", "slot", "when can i come", "when are you",
  "make an appointment", "make a booking", "come in", "visit", "see you",
  "consultation", "session", "treatment", "service",
];

function detectBookingIntent(message: string): boolean {
  const lower = message.toLowerCase();
  return BOOKING_KEYWORDS.some((kw) => lower.includes(kw));
}

async function hasBookingForSession(sessionId: string): Promise<boolean> {
  const existing = await db
    .select({ id: bookingsTable.id })
    .from(bookingsTable)
    .where(eq(bookingsTable.sessionId, sessionId))
    .limit(1);
  return existing.length > 0;
}

interface ExtractedBooking {
  name: string | null;
  email: string | null;
  phone: string | null;
  service: string | null;
  preferredDate: string | null;
  preferredTime: string | null;
  notes: string | null;
  complete: boolean;
}

async function tryExtractBooking(
  history: Array<{ role: string; content: string }>,
): Promise<ExtractedBooking | null> {
  try {
    const { openai } = await import("@workspace/integrations-openai-ai-server" as string);
    const result = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 300,
      messages: [
        {
          role: "system",
          content: `Extract booking details from this conversation. Return ONLY valid JSON with these fields:
{"name":string|null,"email":string|null,"phone":string|null,"service":string|null,"preferredDate":string|null,"preferredTime":string|null,"notes":string|null,"complete":boolean}
Set "complete" to true only when at minimum a name AND (a date or a time or a service) are present. Use null for missing fields. No extra text.`,
        },
        ...history.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
      ],
    });

    const raw = result.choices[0]?.message?.content ?? "";
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return null;
    return JSON.parse(match[0]) as ExtractedBooking;
  } catch {
    return null;
  }
}

async function isSessionFlagged(sessionId: string): Promise<boolean> {
  const existing = await db
    .select({ id: handoffsTable.id })
    .from(handoffsTable)
    .where(eq(handoffsTable.sessionId, sessionId))
    .limit(1);
  return existing.length > 0;
}

async function generateAIReply(
  userMessage: string,
  sessionId: string,
  faqs: Array<{ question: string; answer: string }>,
  bookingMode = false,
): Promise<string> {
  try {
    const { openai } = await import(
      "@workspace/integrations-openai-ai-server" as string
    );

    const faqContext =
      faqs.length > 0
        ? `\n\nKnowledge base (FAQ):\n${faqs.map((f) => `Q: ${f.question}\nA: ${f.answer}`).join("\n\n")}`
        : "";

    const bookingPrompt = bookingMode
      ? `\n\nBOOKING MODE: This customer wants to book an appointment. Collect the following conversationally (one or two pieces at a time, never all at once):
1. What service or treatment they want
2. Their preferred date
3. Their preferred time
4. Their name
5. Their contact details (phone or email)
Once you have at least their name and one other detail, warmly summarise what you have collected and let them know the team will confirm shortly.`
      : "";

    const systemPrompt = `You are a helpful AI customer support assistant for a small business. Your goal is to:
1. Answer customer questions helpfully and concisely
2. Recommend services when relevant
3. Detect when customers are interested in buying/pricing and mention the available plans
4. Be warm, professional, and focused on converting interested visitors into clients

Available pricing plans:
- Starter: £20/month — Perfect for solo businesses
- Business: £50/month — Ideal for growing businesses  
- Premium: £99/month — Full-scale AI support

If someone asks about pricing, setup, or wants to get started, mention the plans and tell them they can click the payment button to get started.${faqContext}${bookingPrompt}

Keep responses concise (2-4 sentences max). Do not use emojis.`;

    const history = await db
      .select()
      .from(chatMessagesTable)
      .where(eq(chatMessagesTable.sessionId, sessionId))
      .orderBy(chatMessagesTable.createdAt)
      .limit(10);

    const messages: Array<{ role: "user" | "assistant" | "system"; content: string }> = [
      { role: "system", content: systemPrompt },
      ...history.map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
      { role: "user", content: userMessage },
    ];

    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 300,
      messages,
    });

    return (
      completion.choices[0]?.message?.content ??
      "I'm here to help! Could you tell me more about what you're looking for?"
    );
  } catch {
    return "Thanks for reaching out! I'd be happy to help you. Could you tell me more about your business and what you're looking for?";
  }
}

const router: IRouter = Router();

router.post("/chat/message", async (req, res): Promise<void> => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { message, sessionId } = parsed.data;
  const intentDetected = detectBuyingIntent(message);

  // Save user message
  await db.insert(chatMessagesTable).values({
    sessionId,
    role: "user",
    content: message,
    intentDetected,
  });

  // Check for handoff request — flag session and alert owner (once per session)
  const handoffKeyword = detectHandoffRequest(message);
  let handoffTriggered = false;
  if (handoffKeyword && !(await isSessionFlagged(sessionId))) {
    handoffTriggered = true;
    const transcript = await db
      .select()
      .from(chatMessagesTable)
      .where(eq(chatMessagesTable.sessionId, sessionId))
      .orderBy(chatMessagesTable.createdAt);

    await db.insert(handoffsTable).values({
      sessionId,
      flagReason: `Keyword matched: "${handoffKeyword}"`,
      triggerMessage: message,
    });

    sendHandoffAlert({
      sessionId,
      triggerMessage: message,
      flagReason: `Keyword matched: "${handoffKeyword}"`,
      transcript: transcript.map((m) => ({ role: m.role, content: m.content })),
    }).catch(() => {});
  }

  // Check booking intent and whether this session already has a booking
  const bookingIntentInMessage = detectBookingIntent(message);
  const sessionAlreadyBooked = bookingIntentInMessage ? await hasBookingForSession(sessionId) : false;

  // Look at full session history to decide if we are already in booking mode
  const sessionHistory = await db
    .select()
    .from(chatMessagesTable)
    .where(eq(chatMessagesTable.sessionId, sessionId))
    .orderBy(chatMessagesTable.createdAt);

  const priorMessages = sessionHistory.map((m) => ({ role: m.role, content: m.content }));
  const sessionHasBookingIntent =
    bookingIntentInMessage ||
    priorMessages.some((m) => m.role === "user" && detectBookingIntent(m.content));
  const inBookingMode = sessionHasBookingIntent && !sessionAlreadyBooked;

  // Get FAQ context
  const { faqTable } = await import("@workspace/db");
  const faqs = await db.select().from(faqTable);

  // Generate AI reply — acknowledge handoff if just triggered, pass booking mode
  const aiReply = await generateAIReply(message, sessionId, faqs, inBookingMode);
  const reply = handoffTriggered
    ? `I've flagged this conversation and a member of our team will follow up with you directly as soon as possible. ${aiReply}`
    : aiReply;
  const replyIntentDetected = detectBuyingIntent(reply) || intentDetected;

  // Save assistant reply
  await db.insert(chatMessagesTable).values({
    sessionId,
    role: "assistant",
    content: reply,
    intentDetected: replyIntentDetected,
  });

  // Try to extract and save a booking if in booking mode
  if (inBookingMode) {
    const fullHistory = [
      ...priorMessages,
      { role: "user", content: message },
      { role: "assistant", content: reply },
    ];
    tryExtractBooking(fullHistory).then(async (extracted) => {
      if (!extracted?.complete) return;
      // Double-check no booking already saved (race guard)
      if (await hasBookingForSession(sessionId)) return;
      await db.insert(bookingsTable).values({
        sessionId,
        name: extracted.name,
        email: extracted.email,
        phone: extracted.phone,
        service: extracted.service,
        preferredDate: extracted.preferredDate,
        preferredTime: extracted.preferredTime,
        notes: extracted.notes,
      });
      sendBookingNotification({
        sessionId,
        name: extracted.name,
        email: extracted.email,
        phone: extracted.phone,
        service: extracted.service,
        preferredDate: extracted.preferredDate,
        preferredTime: extracted.preferredTime,
      }).catch(() => {});
    }).catch(() => {});
  }

  res.json(
    SendChatMessageResponse.parse({
      reply,
      sessionId,
      intentDetected: replyIntentDetected,
      redirectToPayment: replyIntentDetected,
      paymentUrl: replyIntentDetected ? PAYPAL_URL : null,
    }),
  );
});

router.get("/chat/logs", async (req, res): Promise<void> => {
  const query = GetChatLogsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { page = 1, limit = 20 } = query.data;
  const offset = (page - 1) * limit;

  // Get distinct sessions with aggregates
  const sessions = await db
    .select({
      sessionId: chatMessagesTable.sessionId,
      messageCount: count(chatMessagesTable.id),
      intentDetected: sql<boolean>`bool_or(${chatMessagesTable.intentDetected})`,
      createdAt: sql<Date>`min(${chatMessagesTable.createdAt})`,
    })
    .from(chatMessagesTable)
    .groupBy(chatMessagesTable.sessionId)
    .orderBy(desc(sql`min(${chatMessagesTable.createdAt})`))
    .limit(limit)
    .offset(offset);

  const [{ total }] = await db
    .select({ total: sql<number>`count(distinct ${chatMessagesTable.sessionId})::int` })
    .from(chatMessagesTable);

  // Try to match leads to sessions
  const sessionIds = sessions.map((s) => s.sessionId);
  const leads =
    sessionIds.length > 0
      ? await db
          .select()
          .from(leadsTable)
          .where(sql`${leadsTable.sessionId} = ANY(${sql`ARRAY[${sql.join(sessionIds.map((id) => sql`${id}`), sql`, `)}]::text[]`})`)
      : [];

  const leadMap = new Map(leads.map((l) => [l.sessionId, l]));

  res.json(
    GetChatLogsResponse.parse({
      sessions: sessions.map((s) => ({
        sessionId: s.sessionId,
        messageCount: Number(s.messageCount),
        intentDetected: Boolean(s.intentDetected),
        createdAt: new Date(s.createdAt).toISOString(),
        leadName: leadMap.get(s.sessionId)?.name ?? null,
        leadEmail: leadMap.get(s.sessionId)?.email ?? null,
      })),
      total: Number(total),
    }),
  );
});

router.get("/chat/logs/:sessionId", async (req, res): Promise<void> => {
  const params = GetChatSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const messages = await db
    .select()
    .from(chatMessagesTable)
    .where(eq(chatMessagesTable.sessionId, params.data.sessionId))
    .orderBy(chatMessagesTable.createdAt);

  res.json(
    GetChatSessionResponse.parse(
      messages.map((m) => ({
        ...m,
        createdAt: m.createdAt.toISOString(),
      })),
    ),
  );
});

export default router;
