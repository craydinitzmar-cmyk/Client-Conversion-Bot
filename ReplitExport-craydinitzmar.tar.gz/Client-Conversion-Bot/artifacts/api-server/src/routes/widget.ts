import { Router, type IRouter } from "express";

const PAYPAL_URL =
  "https://www.paypal.com/qrcodes/managed/fe032ce3-cfc8-4142-957f-0fab542284c7";

function buildWidgetScript(origin: string): string {
  return `
(function () {
  'use strict';

  var BOTLY_API = '${origin}/api';
  var PAYPAL_URL = '${PAYPAL_URL}';
  var sessionId = 'botly-' + Math.random().toString(36).slice(2) + Date.now();
  var leadCaptured = false;

  /* ── Styles ─────────────────────────────────────────────── */
  var css = \`
    #botly-btn {
      position: fixed; bottom: 24px; right: 24px; z-index: 99998;
      width: 56px; height: 56px; border-radius: 50%;
      background: #18181b; border: none; cursor: pointer;
      box-shadow: 0 4px 24px rgba(0,0,0,0.22);
      display: flex; align-items: center; justify-content: center;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    #botly-btn:hover { transform: scale(1.08); box-shadow: 0 8px 32px rgba(0,0,0,0.28); }
    #botly-btn svg { width: 26px; height: 26px; fill: #fff; }
    #botly-panel {
      position: fixed; bottom: 92px; right: 24px; z-index: 99999;
      width: 360px; max-width: calc(100vw - 32px);
      background: #fff; border-radius: 20px;
      box-shadow: 0 12px 48px rgba(0,0,0,0.18);
      display: none; flex-direction: column; overflow: hidden;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      border: 1px solid #e4e4e7;
    }
    #botly-panel.open { display: flex; }
    #botly-header {
      background: #18181b; color: #fff; padding: 16px 18px;
      display: flex; align-items: center; gap: 10px;
    }
    #botly-header .avatar {
      width: 36px; height: 36px; border-radius: 50%;
      background: #3f3f46; display: flex; align-items: center; justify-content: center;
    }
    #botly-header .avatar svg { width: 18px; height: 18px; fill: #fff; }
    #botly-header .info { flex: 1; }
    #botly-header .name { font-weight: 700; font-size: 14px; }
    #botly-header .status { font-size: 11px; color: #a1a1aa; margin-top: 1px; }
    #botly-close {
      background: none; border: none; cursor: pointer; padding: 4px;
      color: #a1a1aa; font-size: 18px; line-height: 1;
    }
    #botly-close:hover { color: #fff; }
    #botly-messages {
      flex: 1; overflow-y: auto; padding: 16px; display: flex;
      flex-direction: column; gap: 10px; max-height: 320px; min-height: 200px;
    }
    .botly-msg {
      max-width: 82%; padding: 10px 14px; border-radius: 16px;
      font-size: 13.5px; line-height: 1.5; word-break: break-word;
    }
    .botly-msg.bot { background: #f4f4f5; color: #18181b; align-self: flex-start; border-bottom-left-radius: 4px; }
    .botly-msg.user { background: #18181b; color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; }
    .botly-msg.typing { color: #71717a; font-style: italic; }
    .botly-cta {
      display: inline-block; margin-top: 8px; padding: 8px 16px;
      background: #18181b; color: #fff; border-radius: 10px;
      font-size: 12px; font-weight: 600; text-decoration: none;
      transition: background 0.15s;
    }
    .botly-cta:hover { background: #3f3f46; }
    #botly-lead-form {
      padding: 14px 16px; background: #fafafa; border-top: 1px solid #f0f0f0;
      display: none; flex-direction: column; gap: 8px;
    }
    #botly-lead-form.visible { display: flex; }
    #botly-lead-form p { font-size: 12px; color: #71717a; margin: 0 0 4px; }
    #botly-lead-form input {
      border: 1px solid #e4e4e7; border-radius: 8px; padding: 8px 12px;
      font-size: 13px; outline: none; background: #fff;
    }
    #botly-lead-form input:focus { border-color: #18181b; }
    #botly-lead-btn {
      background: #18181b; color: #fff; border: none; border-radius: 8px;
      padding: 9px; font-size: 13px; font-weight: 600; cursor: pointer;
    }
    #botly-lead-btn:hover { background: #3f3f46; }
    #botly-input-row {
      display: flex; gap: 8px; padding: 12px 14px; border-top: 1px solid #f0f0f0;
      background: #fff;
    }
    #botly-input {
      flex: 1; border: 1px solid #e4e4e7; border-radius: 10px;
      padding: 9px 12px; font-size: 13px; outline: none; resize: none;
      font-family: inherit;
    }
    #botly-input:focus { border-color: #18181b; }
    #botly-send {
      background: #18181b; border: none; border-radius: 10px;
      width: 38px; height: 38px; display: flex; align-items: center;
      justify-content: center; cursor: pointer; flex-shrink: 0;
    }
    #botly-send:hover { background: #3f3f46; }
    #botly-send svg { width: 16px; height: 16px; fill: #fff; }
  \`;

  var style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  /* ── HTML ────────────────────────────────────────────────── */
  var container = document.createElement('div');
  container.innerHTML = \`
    <button id="botly-btn" aria-label="Open chat">
      <svg viewBox="0 0 24 24"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm-2 10H6V8h12v4z"/></svg>
    </button>
    <div id="botly-panel" role="dialog" aria-label="Chat with us">
      <div id="botly-header">
        <div class="avatar"><svg viewBox="0 0 24 24"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7H3a7 7 0 0 1 7-7h1V5.73A2 2 0 0 1 10 4a2 2 0 0 1 2-2M5 16v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2H5m5 2h4"/></svg></div>
        <div class="info">
          <div class="name">Botly Assistant</div>
          <div class="status">Online — replies in seconds</div>
        </div>
        <button id="botly-close" aria-label="Close chat">&#x2715;</button>
      </div>
      <div id="botly-messages"></div>
      <div id="botly-lead-form">
        <p>Before we continue, what is your name and email?</p>
        <input id="botly-lead-name" type="text" placeholder="Your name" />
        <input id="botly-lead-email" type="email" placeholder="Your email" />
        <button id="botly-lead-btn">Continue</button>
      </div>
      <div id="botly-input-row">
        <textarea id="botly-input" rows="1" placeholder="Type a message..."></textarea>
        <button id="botly-send" aria-label="Send">
          <svg viewBox="0 0 24 24"><path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/></svg>
        </button>
      </div>
    </div>
  \`;
  document.body.appendChild(container);

  /* ── Elements ────────────────────────────────────────────── */
  var btn     = document.getElementById('botly-btn');
  var panel   = document.getElementById('botly-panel');
  var closeEl = document.getElementById('botly-close');
  var msgs    = document.getElementById('botly-messages');
  var input   = document.getElementById('botly-input');
  var sendBtn = document.getElementById('botly-send');
  var leadForm = document.getElementById('botly-lead-form');
  var leadName  = document.getElementById('botly-lead-name');
  var leadEmail = document.getElementById('botly-lead-email');
  var leadBtn  = document.getElementById('botly-lead-btn');

  /* ── Helpers ─────────────────────────────────────────────── */
  function addMsg(text, role, withCta) {
    var el = document.createElement('div');
    el.className = 'botly-msg ' + (role || 'bot');
    el.textContent = text;
    if (withCta) {
      var a = document.createElement('a');
      a.href = PAYPAL_URL;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.className = 'botly-cta';
      a.textContent = 'Get Started Now';
      el.appendChild(document.createElement('br'));
      el.appendChild(a);
    }
    msgs.appendChild(el);
    msgs.scrollTop = msgs.scrollHeight;
    return el;
  }

  function showTyping() {
    return addMsg('Typing...', 'bot typing');
  }

  function greet() {
    addMsg('Hi! I am your AI assistant. How can I help you today?', 'bot');
  }

  function showLeadForm() {
    leadForm.classList.add('visible');
    leadName.focus();
  }

  /* ── Lead capture ────────────────────────────────────────── */
  leadBtn.addEventListener('click', function () {
    var name  = leadName.value.trim();
    var email = leadEmail.value.trim();
    if (!name || !email) return;
    leadCaptured = true;
    leadForm.classList.remove('visible');
    fetch(BOTLY_API + '/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name, email: email, sessionId: sessionId })
    }).catch(function () {});
    addMsg('Thanks ' + name + '! Let me know if you have any more questions.', 'bot');
  });

  /* ── Send message ────────────────────────────────────────── */
  function send() {
    var text = input.value.trim();
    if (!text) return;
    input.value = '';
    addMsg(text, 'user');
    var typing = showTyping();
    fetch(BOTLY_API + '/chat/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, sessionId: sessionId })
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        msgs.removeChild(typing);
        addMsg(data.reply, 'bot', data.intentDetected);
        if (data.intentDetected && !leadCaptured) {
          setTimeout(showLeadForm, 600);
        }
      })
      .catch(function () {
        msgs.removeChild(typing);
        addMsg('Sorry, something went wrong. Please try again.', 'bot');
      });
  }

  sendBtn.addEventListener('click', send);
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  });

  /* ── Toggle panel ────────────────────────────────────────── */
  var opened = false;
  btn.addEventListener('click', function () {
    panel.classList.toggle('open');
    if (!opened) { greet(); opened = true; }
  });
  closeEl.addEventListener('click', function () {
    panel.classList.remove('open');
  });
})();
`.trim();
}

const router: IRouter = Router();

router.get("/widget.js", (req, res): void => {
  const origin =
    process.env.REPLIT_DOMAINS
      ? `https://${process.env.REPLIT_DOMAINS.split(",")[0].trim()}`
      : `${req.protocol}://${req.get("host")}`;

  const script = buildWidgetScript(origin);

  res.setHeader("Content-Type", "application/javascript; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=300");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.send(script);
});

export default router;
