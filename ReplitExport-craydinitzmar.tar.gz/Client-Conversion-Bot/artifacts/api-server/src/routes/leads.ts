import { Router, type IRouter } from "express";
import { eq, ilike, desc, sql } from "drizzle-orm";
import { db, leadsTable } from "@workspace/db";
import {
  GetLeadsQueryParams,
  GetLeadsResponse,
  CreateLeadBody,
  GetLeadParams,
  GetLeadResponse,
  DeleteLeadParams,
} from "@workspace/api-zod";
import { sendLeadNotification } from "../email";
import { scheduleEmailSequence } from "../email-sequence";

const router: IRouter = Router();

router.get("/leads", async (req, res): Promise<void> => {
  const query = GetLeadsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { search, page = 1, limit = 20 } = query.data;
  const offset = (page - 1) * limit;

  let baseQuery = db.select().from(leadsTable);

  const leads = await (search
    ? db
        .select()
        .from(leadsTable)
        .where(ilike(leadsTable.name, `%${search}%`))
        .orderBy(desc(leadsTable.createdAt))
        .limit(limit)
        .offset(offset)
    : db
        .select()
        .from(leadsTable)
        .orderBy(desc(leadsTable.createdAt))
        .limit(limit)
        .offset(offset));

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(leadsTable);

  res.json(
    GetLeadsResponse.parse({
      leads: leads.map((l) => ({
        ...l,
        createdAt: l.createdAt.toISOString(),
      })),
      total: count,
    }),
  );
});

router.post("/leads", async (req, res): Promise<void> => {
  const parsed = CreateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [lead] = await db.insert(leadsTable).values(parsed.data).returning();

  // Fire notifications and schedule email sequence without blocking the response
  sendLeadNotification({
    name: lead.name,
    email: lead.email,
    phone: lead.phone,
    sessionId: lead.sessionId ?? "",
    createdAt: lead.createdAt.toISOString(),
  }).catch(() => {});
  scheduleEmailSequence({
    leadId: lead.id,
    toEmail: lead.email,
    toName: lead.name,
  }).catch(() => {});

  res.status(201).json(
    GetLeadResponse.parse({
      ...lead,
      createdAt: lead.createdAt.toISOString(),
    }),
  );
});

router.get("/leads/:id", async (req, res): Promise<void> => {
  const params = GetLeadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [lead] = await db
    .select()
    .from(leadsTable)
    .where(eq(leadsTable.id, params.data.id));

  if (!lead) {
    res.status(404).json({ error: "Lead not found" });
    return;
  }

  res.json(
    GetLeadResponse.parse({
      ...lead,
      createdAt: lead.createdAt.toISOString(),
    }),
  );
});

router.delete("/leads/:id", async (req, res): Promise<void> => {
  const params = DeleteLeadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [lead] = await db
    .delete(leadsTable)
    .where(eq(leadsTable.id, params.data.id))
    .returning();

  if (!lead) {
    res.status(404).json({ error: "Lead not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
