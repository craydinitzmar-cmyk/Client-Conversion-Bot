import { Router, type IRouter } from "express";
import healthRouter from "./health";
import leadsRouter from "./leads";
import chatRouter from "./chat";
import faqRouter from "./faq";
import settingsRouter from "./settings";
import statsRouter from "./stats";
import widgetRouter from "./widget";
import referralsRouter from "./referrals";
import emailQueueRouter from "./email-queue";
import handoffsRouter from "./handoffs";
import bookingsRouter from "./bookings";
import testimonialsRouter from "./testimonials";
import prospectsRouter from "./prospects";

const router: IRouter = Router();

router.use(healthRouter);
router.use(leadsRouter);
router.use(chatRouter);
router.use(faqRouter);
router.use(settingsRouter);
router.use(statsRouter);
router.use(widgetRouter);
router.use(referralsRouter);
router.use(emailQueueRouter);
router.use(handoffsRouter);
router.use(bookingsRouter);
router.use(testimonialsRouter);
router.use(prospectsRouter);

export default router;
