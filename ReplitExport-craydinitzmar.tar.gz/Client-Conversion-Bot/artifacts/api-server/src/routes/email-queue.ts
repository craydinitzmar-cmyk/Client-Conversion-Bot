import { Router, type IRouter } from "express";
import { desc, eq, sql } from "drizzle-orm";
import { db, emailQueueTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/email-queue", async (_req, res): Promise<void> => {
  const items = await db
    .select()
    .from(emailQueueTable)
    .orderBy(desc(emailQueueTable.createdAt));

  const [stats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      sent: sql<number>`count(*) filter (where status = 'sent')::int`,
      pending: sql<number>`count(*) filter (where status = 'pending')::int`,
      failed: sql<number>`count(*) filter (where status = 'failed')::int`,
    })
    .from(emailQueueTable);

  res.json({
    items: items.map((i) => ({
      id: i.id,
      leadId: i.leadId,
      toName: i.toName,
      toEmail: i.toEmail,
      subject: i.subject,
      sequenceStep: i.sequenceStep,
      status: i.status,
      scheduledAt: i.scheduledAt.toISOString(),
      sentAt: i.sentAt?.toISOString() ?? null,
      errorMessage: i.errorMessage,
      createdAt: i.createdAt.toISOString(),
    })),
    total: Number(stats.total),
    sent: Number(stats.sent),
    pending: Number(stats.pending),
    failed: Number(stats.failed),
  });
});

export default router;
