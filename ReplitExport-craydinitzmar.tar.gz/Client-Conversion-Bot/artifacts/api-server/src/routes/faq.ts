import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, faqTable } from "@workspace/db";
import {
  GetFaqsResponse,
  CreateFaqBody,
  UpdateFaqParams,
  UpdateFaqBody,
  UpdateFaqResponse,
  DeleteFaqParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/faq", async (_req, res): Promise<void> => {
  const faqs = await db.select().from(faqTable);
  res.json(GetFaqsResponse.parse(faqs));
});

router.post("/faq", async (req, res): Promise<void> => {
  const parsed = CreateFaqBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [faq] = await db.insert(faqTable).values(parsed.data).returning();
  res.status(201).json(faq);
});

router.put("/faq/:id", async (req, res): Promise<void> => {
  const params = UpdateFaqParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateFaqBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [faq] = await db
    .update(faqTable)
    .set(parsed.data)
    .where(eq(faqTable.id, params.data.id))
    .returning();

  if (!faq) {
    res.status(404).json({ error: "FAQ not found" });
    return;
  }

  res.json(UpdateFaqResponse.parse(faq));
});

router.delete("/faq/:id", async (req, res): Promise<void> => {
  const params = DeleteFaqParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [faq] = await db
    .delete(faqTable)
    .where(eq(faqTable.id, params.data.id))
    .returning();

  if (!faq) {
    res.status(404).json({ error: "FAQ not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
