import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { referralsTable } from "@workspace/db";

const router: IRouter = Router();

function isValidEmail(v: unknown): v is string {
  return typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

function generateCode(email: string): string {
  let hash = 0;
  const str = email.toLowerCase() + Date.now().toString();
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  let n = Math.abs(hash);
  for (let i = 0; i < 8; i++) {
    code += chars[n % chars.length];
    n = Math.floor(n / chars.length) || (n + 1);
  }
  return code;
}

// GET /api/referrals/code?email=xxx — get or create a referral code
router.get("/referrals/code", async (req, res): Promise<void> => {
  const email = req.query.email;
  if (!isValidEmail(email)) {
    res.status(400).json({ error: "Valid email required" });
    return;
  }

  const existing = await db
    .select()
    .from(referralsTable)
    .where(eq(referralsTable.referrerEmail, email))
    .limit(1);

  if (existing.length > 0) {
    res.json({ code: existing[0].referralCode, email });
    return;
  }

  let code = generateCode(email);
  const conflict = await db
    .select()
    .from(referralsTable)
    .where(eq(referralsTable.referralCode, code))
    .limit(1);
  if (conflict.length > 0) code = generateCode(email + Math.random());

  await db.insert(referralsTable).values({ referrerEmail: email, referralCode: code });
  res.json({ code, email });
});

// POST /api/referrals/convert — mark a referral converted
router.post("/referrals/convert", async (req, res): Promise<void> => {
  const { refCode, referredEmail, referredName } = req.body ?? {};
  if (typeof refCode !== "string" || !refCode.trim()) {
    res.status(400).json({ error: "refCode required" });
    return;
  }

  const [ref] = await db
    .select()
    .from(referralsTable)
    .where(eq(referralsTable.referralCode, refCode.trim().toUpperCase()))
    .limit(1);

  if (!ref) {
    res.status(404).json({ error: "Referral code not found" });
    return;
  }

  if (ref.status === "converted") {
    res.json({ already: true });
    return;
  }

  await db
    .update(referralsTable)
    .set({
      referredEmail: typeof referredEmail === "string" ? referredEmail : null,
      referredName: typeof referredName === "string" ? referredName : null,
      status: "converted",
      convertedAt: new Date(),
    })
    .where(eq(referralsTable.id, ref.id));

  res.json({ success: true, reward: ref.reward });
});

// GET /api/referrals/stats?email=xxx — stats for a referrer
router.get("/referrals/stats", async (req, res): Promise<void> => {
  const email = req.query.email;
  if (!isValidEmail(email)) {
    res.status(400).json({ error: "Valid email required" });
    return;
  }

  const refs = await db
    .select()
    .from(referralsTable)
    .where(eq(referralsTable.referrerEmail, email))
    .orderBy(desc(referralsTable.createdAt));

  const converted = refs.filter((r) => r.status === "converted").length;

  res.json({
    total: refs.length,
    converted,
    pending: refs.length - converted,
    monthsFree: converted,
    referrals: refs.map((r) => ({
      id: r.id,
      code: r.referralCode,
      referredEmail: r.referredEmail,
      referredName: r.referredName,
      status: r.status,
      createdAt: r.createdAt.toISOString(),
      convertedAt: r.convertedAt?.toISOString() ?? null,
    })),
  });
});

// GET /api/referrals — admin: all referrals
router.get("/referrals", async (_req, res): Promise<void> => {
  const all = await db
    .select()
    .from(referralsTable)
    .orderBy(desc(referralsTable.createdAt));

  const [{ totalConverted }] = await db
    .select({
      totalConverted: sql<number>`count(*) filter (where status = 'converted')::int`,
    })
    .from(referralsTable);

  res.json({
    referrals: all.map((r) => ({
      id: r.id,
      referrerEmail: r.referrerEmail,
      code: r.referralCode,
      referredEmail: r.referredEmail,
      referredName: r.referredName,
      status: r.status,
      reward: r.reward,
      createdAt: r.createdAt.toISOString(),
      convertedAt: r.convertedAt?.toISOString() ?? null,
    })),
    total: all.length,
    totalConverted: Number(totalConverted),
  });
});

export default router;
