import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, prospectsTable } from "@workspace/db";

const router: IRouter = Router();

// GET /api/prospects
router.get("/prospects", async (_req, res): Promise<void> => {
  const rows = await db.select().from(prospectsTable).orderBy(desc(prospectsTable.createdAt));
  res.json({ prospects: rows });
});

// POST /api/prospects
router.post("/prospects", async (req, res): Promise<void> => {
  const { businessName, industry, contactName, email, website, notes } = req.body ?? {};
  if (!businessName || !industry) { res.status(400).json({ error: "businessName and industry required" }); return; }
  const [row] = await db.insert(prospectsTable).values({
    businessName: String(businessName),
    industry: String(industry),
    contactName: contactName ? String(contactName) : null,
    email: email ? String(email) : null,
    website: website ? String(website) : null,
    notes: notes ? String(notes) : null,
  }).returning();
  res.status(201).json({ id: row.id });
});

// POST /api/prospects/:id/generate-outreach
router.post("/prospects/:id/generate-outreach", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const [p] = await db.select().from(prospectsTable).where(eq(prospectsTable.id, id));
  if (!p) { res.status(404).json({ error: "not found" }); return; }

  try {
    const { openai } = await import("@workspace/integrations-openai-ai-server" as string);
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 400,
      messages: [
        {
          role: "system",
          content: `You write short, warm, personalised cold outreach emails on behalf of Botly — an AI customer support SaaS for small businesses (£20-£99/mo). The email should:
- Address the owner by first name if available, otherwise "Hi there"
- Reference their specific industry and what Botly could do for them (e.g. answer FAQs, capture bookings, generate leads 24/7)
- Sound human and friendly, not salesy
- Include a soft CTA to try 7 days free at https://botly.replit.app/free-trial
- Be under 120 words
- No emojis`,
        },
        {
          role: "user",
          content: `Write an outreach email for:
Business: ${p.businessName}
Industry: ${p.industry}
Contact name: ${p.contactName ?? "unknown"}
Notes: ${p.notes ?? "none"}`,
        },
      ],
    });
    const email = completion.choices[0]?.message?.content ?? "";
    res.json({ email });
  } catch {
    res.status(500).json({ error: "AI generation failed" });
  }
});

// POST /api/prospects/:id/send-outreach
router.post("/prospects/:id/send-outreach", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const [p] = await db.select().from(prospectsTable).where(eq(prospectsTable.id, id));
  if (!p) { res.status(404).json({ error: "not found" }); return; }

  const emailBody = req.body?.email;
  if (!emailBody) { res.status(400).json({ error: "email body required" }); return; }

  const toEmail = p.email;
  if (!toEmail) { res.status(400).json({ error: "prospect has no email address" }); return; }

  try {
    const { sendRawEmail } = await import("../email.js");
    await sendRawEmail({
      to: toEmail,
      subject: `A quick question about ${p.businessName}`,
      text: emailBody,
    });
    await db.update(prospectsTable)
      .set({ status: "contacted", outreachSentAt: new Date() })
      .where(eq(prospectsTable.id, id));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Failed to send email" });
  }
});

export default router;
