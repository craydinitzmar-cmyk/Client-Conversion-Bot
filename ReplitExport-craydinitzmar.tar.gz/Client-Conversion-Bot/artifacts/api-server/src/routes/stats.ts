import { Router, type IRouter } from "express";
import { sql } from "drizzle-orm";
import { db, leadsTable, chatMessagesTable } from "@workspace/db";
import { GetStatsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const [{ totalLeads }] = await db
    .select({ totalLeads: sql<number>`count(*)::int` })
    .from(leadsTable);

  const [{ totalSessions }] = await db
    .select({
      totalSessions: sql<number>`count(distinct ${chatMessagesTable.sessionId})::int`,
    })
    .from(chatMessagesTable);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [{ todayLeads }] = await db
    .select({ todayLeads: sql<number>`count(*)::int` })
    .from(leadsTable)
    .where(sql`${leadsTable.createdAt} >= ${today}`);

  const [{ intentDetectedCount }] = await db
    .select({
      intentDetectedCount: sql<number>`count(distinct ${chatMessagesTable.sessionId})::int`,
    })
    .from(chatMessagesTable)
    .where(sql`${chatMessagesTable.intentDetected} = true`);

  const conversionRate =
    totalSessions > 0
      ? Math.round((totalLeads / totalSessions) * 100) / 100
      : 0;

  res.json(
    GetStatsResponse.parse({
      totalLeads: Number(totalLeads),
      totalSessions: Number(totalSessions),
      todayLeads: Number(todayLeads),
      intentDetectedCount: Number(intentDetectedCount),
      conversionRate,
    }),
  );
});

export default router;
