import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db, bookingsTable } from "@workspace/db";

const router: IRouter = Router();

// GET /api/bookings
router.get("/bookings", async (_req, res): Promise<void> => {
  const bookings = await db
    .select()
    .from(bookingsTable)
    .orderBy(desc(bookingsTable.createdAt));

  const [stats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      pending: sql<number>`count(*) filter (where status = 'pending')::int`,
      confirmed: sql<number>`count(*) filter (where status = 'confirmed')::int`,
      cancelled: sql<number>`count(*) filter (where status = 'cancelled')::int`,
    })
    .from(bookingsTable);

  res.json({
    bookings: bookings.map((b) => ({
      id: b.id,
      sessionId: b.sessionId,
      name: b.name,
      email: b.email,
      phone: b.phone,
      service: b.service,
      preferredDate: b.preferredDate,
      preferredTime: b.preferredTime,
      notes: b.notes,
      status: b.status,
      createdAt: b.createdAt.toISOString(),
      updatedAt: b.updatedAt.toISOString(),
    })),
    total: Number(stats.total),
    pending: Number(stats.pending),
    confirmed: Number(stats.confirmed),
    cancelled: Number(stats.cancelled),
  });
});

// PATCH /api/bookings/:id/status
router.patch("/bookings/:id/status", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const status = req.body?.status;
  if (!["pending", "confirmed", "cancelled"].includes(status)) {
    res.status(400).json({ error: "status must be pending, confirmed, or cancelled" });
    return;
  }

  const [updated] = await db
    .update(bookingsTable)
    .set({ status, updatedAt: new Date() })
    .where(eq(bookingsTable.id, id))
    .returning();

  if (!updated) { res.status(404).json({ error: "Not found" }); return; }

  res.json({ id: updated.id, status: updated.status });
});

export default router;
