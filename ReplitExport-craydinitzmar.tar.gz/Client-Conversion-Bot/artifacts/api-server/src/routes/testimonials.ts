import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, testimonialsTable } from "@workspace/db";

const router: IRouter = Router();

// GET /api/testimonials — approved only (public)
router.get("/testimonials", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(testimonialsTable)
    .where(eq(testimonialsTable.approved, true))
    .orderBy(desc(testimonialsTable.createdAt));
  res.json({ testimonials: rows });
});

// GET /api/testimonials/all — all (dashboard)
router.get("/testimonials/all", async (_req, res): Promise<void> => {
  const rows = await db.select().from(testimonialsTable).orderBy(desc(testimonialsTable.createdAt));
  res.json({ testimonials: rows });
});

// POST /api/testimonials — submit new review
router.post("/testimonials", async (req, res): Promise<void> => {
  const { name, role, quote, rating } = req.body ?? {};
  if (!name || !role || !quote) { res.status(400).json({ error: "name, role and quote required" }); return; }
  const [row] = await db.insert(testimonialsTable).values({
    name: String(name),
    role: String(role),
    quote: String(quote),
    rating: Math.min(5, Math.max(1, Number(rating) || 5)),
    approved: false,
  }).returning();
  res.status(201).json({ id: row.id });
});

// PATCH /api/testimonials/:id/approve
router.patch("/testimonials/:id/approve", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const approved = req.body?.approved !== false;
  const [row] = await db.update(testimonialsTable).set({ approved }).where(eq(testimonialsTable.id, id)).returning();
  if (!row) { res.status(404).json({ error: "not found" }); return; }
  res.json({ id: row.id, approved: row.approved });
});

// DELETE /api/testimonials/:id
router.delete("/testimonials/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "invalid id" }); return; }
  await db.delete(testimonialsTable).where(eq(testimonialsTable.id, id));
  res.json({ ok: true });
});

export default router;
