import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db, handoffsTable, chatMessagesTable } from "@workspace/db";

const router: IRouter = Router();

// GET /api/handoffs — all flagged sessions for admin
router.get("/handoffs", async (_req, res): Promise<void> => {
  const handoffs = await db
    .select()
    .from(handoffsTable)
    .orderBy(desc(handoffsTable.flaggedAt));

  const [{ total, pending }] = await db
    .select({
      total: sql<number>`count(*)::int`,
      pending: sql<number>`count(*) filter (where status = 'pending')::int`,
    })
    .from(handoffsTable);

  // Attach last few messages for each session
  const withTranscripts = await Promise.all(
    handoffs.map(async (h) => {
      const messages = await db
        .select()
        .from(chatMessagesTable)
        .where(eq(chatMessagesTable.sessionId, h.sessionId))
        .orderBy(chatMessagesTable.createdAt)
        .limit(20);

      return {
        id: h.id,
        sessionId: h.sessionId,
        flagReason: h.flagReason,
        triggerMessage: h.triggerMessage,
        status: h.status,
        flaggedAt: h.flaggedAt.toISOString(),
        resolvedAt: h.resolvedAt?.toISOString() ?? null,
        resolvedNote: h.resolvedNote,
        messages: messages.map((m) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          createdAt: m.createdAt.toISOString(),
        })),
      };
    })
  );

  res.json({ handoffs: withTranscripts, total: Number(total), pending: Number(pending) });
});

// PATCH /api/handoffs/:id/resolve — mark a handoff as resolved
router.patch("/handoffs/:id/resolve", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const note = typeof req.body?.note === "string" ? req.body.note : null;

  const [updated] = await db
    .update(handoffsTable)
    .set({ status: "resolved", resolvedAt: new Date(), resolvedNote: note })
    .where(eq(handoffsTable.id, id))
    .returning();

  if (!updated) { res.status(404).json({ error: "Not found" }); return; }

  res.json({ id: updated.id, status: updated.status });
});

export default router;
