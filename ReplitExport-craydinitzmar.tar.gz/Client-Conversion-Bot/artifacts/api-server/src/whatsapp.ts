export interface WhatsAppLeadData {
  name: string;
  email: string;
  phone?: string | null;
  sessionId: string;
  createdAt: string;
}

export async function sendWhatsAppLeadNotification(lead: WhatsAppLeadData): Promise<void> {
  const phone = process.env.WHATSAPP_PHONE;
  const apiKey = process.env.WHATSAPP_APIKEY;

  if (!phone || !apiKey) return;

  const dashboardUrl = process.env.REPLIT_DOMAINS
    ? `https://${process.env.REPLIT_DOMAINS.split(",")[0].trim()}/dashboard/leads`
    : "your Botly dashboard";

  const lines = [
    "NEW LEAD - Botly",
    `Name: ${lead.name}`,
    `Email: ${lead.email}`,
    lead.phone ? `Phone: ${lead.phone}` : null,
    `Dashboard: ${dashboardUrl}`,
  ].filter(Boolean);

  const text = encodeURIComponent(lines.join("\n"));
  const url = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(phone)}&text=${text}&apikey=${apiKey}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`CallMeBot error: ${response.status}`);
  }
}
