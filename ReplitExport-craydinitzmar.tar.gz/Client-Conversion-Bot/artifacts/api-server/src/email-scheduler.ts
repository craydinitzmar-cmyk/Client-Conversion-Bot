import { lte, eq } from "drizzle-orm";
import { db, emailQueueTable } from "@workspace/db";
import nodemailer from "nodemailer";
import { logger } from "./lib/logger";

let transporter: nodemailer.Transporter | null = null;

function getTransporter(): nodemailer.Transporter | null {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return transporter;
}

async function processDueEmails(): Promise<void> {
  const transport = getTransporter();
  if (!transport) return;

  const due = await db
    .select()
    .from(emailQueueTable)
    .where(
      eq(emailQueueTable.status, "pending")
    );

  const now = new Date();
  const ready = due.filter((e) => e.scheduledAt <= now);

  if (ready.length === 0) return;

  for (const item of ready) {
    try {
      await transport.sendMail({
        from: `"Botly" <${process.env.SMTP_USER}>`,
        to: `${item.toName} <${item.toEmail}>`,
        subject: item.subject,
        html: item.bodyHtml,
      });

      await db
        .update(emailQueueTable)
        .set({ status: "sent", sentAt: new Date() })
        .where(eq(emailQueueTable.id, item.id));

      logger.info(
        { id: item.id, to: item.toEmail, step: item.sequenceStep },
        "Email sequence step sent"
      );
    } catch (err) {
      await db
        .update(emailQueueTable)
        .set({
          status: "failed",
          errorMessage: err instanceof Error ? err.message : String(err),
        })
        .where(eq(emailQueueTable.id, item.id));

      logger.error(
        { id: item.id, to: item.toEmail, err },
        "Failed to send sequence email"
      );
    }
  }
}

export function startEmailScheduler(): void {
  logger.info("Email sequence scheduler started (60s interval)");
  // Run immediately on startup, then every 60 seconds
  processDueEmails().catch((err) =>
    logger.error({ err }, "Email scheduler error on startup")
  );
  setInterval(() => {
    processDueEmails().catch((err) =>
      logger.error({ err }, "Email scheduler error")
    );
  }, 60_000);
}
